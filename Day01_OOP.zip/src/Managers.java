public class Managers extends Employees {

	private int managerId;
	private int subordinates;

	public Managers(int empId, String empName, String empEmail, String empdept,
			String empPhone, String empHiredate, int empSalary, int managerId,
			int subordinates) {
		super(empId, empName, empEmail, empdept, empPhone, empHiredate,
				empSalary);
		this.managerId = managerId;
		this.subordinates = subordinates;
	}

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public int getSubordinates() {
		return subordinates;
	}

	public void setSubordinates(int subordinates) {
		this.subordinates = subordinates;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + managerId;
		result = prime * result + subordinates;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Managers other = (Managers) obj;
		if (managerId != other.managerId)
			return false;
		if (subordinates != other.subordinates)
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Managers [managerId=");
		builder.append(managerId);
		builder.append(", subordinates=");
		builder.append(subordinates);
		builder.append("]");
		return builder.toString();
	}

}
