public class Employees {
	private int empId;
	private String empName;
	private String empEmail;
	private String empdept;
	private String empPhone;
	private String empHiredate;
	private int empSalary;

	public Employees(int empId, String empName, String empEmail,
			String empdept, String empPhone, String empHiredate, int empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empEmail = empEmail;
		this.empdept = empdept;
		this.empPhone = empPhone;
		this.empHiredate = empHiredate;
		this.empSalary = empSalary;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpEmail() {
		return empEmail;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}

	public String getEmpdept() {
		return empdept;
	}

	public void setEmpdept(String empdept) {
		this.empdept = empdept;
	}

	public String getEmpPhone() {
		return empPhone;
	}

	public void setEmpPhone(String empPhone) {
		this.empPhone = empPhone;
	}

	public String getEmpHiredate() {
		return empHiredate;
	}

	public void setEmpHiredate(String empHiredate) {
		this.empHiredate = empHiredate;
	}

	public int getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((empEmail == null) ? 0 : empEmail.hashCode());
		result = prime * result
				+ ((empHiredate == null) ? 0 : empHiredate.hashCode());
		result = prime * result + empId;
		result = prime * result + ((empName == null) ? 0 : empName.hashCode());
		result = prime * result
				+ ((empPhone == null) ? 0 : empPhone.hashCode());
		result = prime * result + empSalary;
		result = prime * result + ((empdept == null) ? 0 : empdept.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employees other = (Employees) obj;
		if (empEmail == null) {
			if (other.empEmail != null)
				return false;
		} else if (!empEmail.equals(other.empEmail))
			return false;
		if (empHiredate == null) {
			if (other.empHiredate != null)
				return false;
		} else if (!empHiredate.equals(other.empHiredate))
			return false;
		if (empId != other.empId)
			return false;
		if (empName == null) {
			if (other.empName != null)
				return false;
		} else if (!empName.equals(other.empName))
			return false;
		if (empPhone == null) {
			if (other.empPhone != null)
				return false;
		} else if (!empPhone.equals(other.empPhone))
			return false;
		if (empSalary != other.empSalary)
			return false;
		if (empdept == null) {
			if (other.empdept != null)
				return false;
		} else if (!empdept.equals(other.empdept))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Employees [empId=");
		builder.append(empId);
		builder.append(", empName=");
		builder.append(empName);
		builder.append(", empEmail=");
		builder.append(empEmail);
		builder.append(", empdept=");
		builder.append(empdept);
		builder.append(", empPhone=");
		builder.append(empPhone);
		builder.append(", empHiredate=");
		builder.append(empHiredate);
		builder.append(", empSalary=");
		builder.append(empSalary);
		builder.append("]");
		return builder.toString();
	}

}
