import java.util.ArrayList;

public class ManageMain {
	public static void main(String[] args) {

		Employees e1 = new Employees(37720, "박지윤", "j_erika.park@samsung.com",
				"의료원CI그룹", "01099799098", "2015/03/03", 4000);
		Employees e2 = new Employees(38820, "김홍열", "honghong@samsung.com",
				"의료원CI그룹", "01077778080", "2015/02/27", 4000);

		ArrayList<Employees> eeList = new ArrayList<>();
		eeList.add(e1);
		eeList.add(e2);

		for (Employees employees : eeList) {
			System.out.println(employees);
		}
	}
}
