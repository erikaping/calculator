package com.samsung.employee;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateEmp extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		// 응답 페이지의 파일 형식과 언어 타입을 설정해야 한글이 안깨짐
		response.setContentType("text/html; charset=UTF-8");

		PrintWriter out = response.getWriter();

		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			// 1단계 => 사용할 클래스를 올리자
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2단계 => DB연결
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			conn = DriverManager.getConnection(url, "hr", "hr");
			// 3단계 => Query 준비
			// PreparedStatement 객체는 쿼리 실행 및 실행 전에 해야할 일에 대한 메소드를 가지고 있다.
			String sql = "update emp set salary = ?, commission = ?, did = ? where id = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, 5000);
			stmt.setDouble(2, 0.05);
			stmt.setInt(3, 100);
			stmt.setInt(4, 208);

			// 리턴타입 : 몇 개의 쿼리가 실행됐는지의 카운트 수
			int cnt = stmt.executeUpdate();
			System.out.println(cnt + "개가 정상 수정되었습니다.");
			
			//페
			response.sendRedirect("/getEmpList");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
	}

}
