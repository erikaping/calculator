package honeyhobbee.vo;

import org.springframework.stereotype.Component;

@Component
public class Reply {
	private int reply_id;
	private int post_id;
	private String reply_time;
	private String email;
	private String reply_content;

	


	public int getReply_id() {
		return reply_id;
	}

	public void setReply_id(int reply_id) {
		this.reply_id = reply_id;
	}

	public int getPost_id() {
		return post_id;
	}

	public void setPost_id(int post_id) {
		this.post_id = post_id;
	}

	public String getReply_time() {
		return reply_time;
	}

	public void setReply_time(String reply_time) {
		this.reply_time = reply_time;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getReply_content() {
		return reply_content;
	}

	public void setReply_content(String reply_content) {
		this.reply_content = reply_content;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Reply [reply_id=");
		builder.append(reply_id);
		builder.append(", post_id=");
		builder.append(post_id);
		builder.append(", reply_time=");
		builder.append(reply_time);
		builder.append(", email=");
		builder.append(email);
		builder.append(", reply_content=");
		builder.append(reply_content);
		builder.append("]");
		return builder.toString();
	}

}
