package honeyhobbee.vo;

import org.springframework.stereotype.Component;

@Component
public class Job {

	int job_id;
	String job_name;

	public int getJob_id() {
		return job_id;
	}

	public void setJob_id(int job_id) {
		this.job_id = job_id;
	}

	public String getJob_name() {
		return job_name;
	}

	public void setJob_name(String job_name) {
		this.job_name = job_name;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Job [job_id=");
		builder.append(job_id);
		builder.append(", job_name=");
		builder.append(job_name);
		builder.append("]");
		return builder.toString();
	}

}
