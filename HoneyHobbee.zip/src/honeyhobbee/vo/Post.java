package honeyhobbee.vo;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class Post {
	private int post_id;
	private String post_title;
	private String post_content;
	private String post_time;
	private int hobby_id;
	private int post_like;
	private String email;
	private String name;
	private String post_image;

	// 추가됨
	private int tag_id1;
	private int tag_id2;
	private int tag_id3;

	private String tag_name1;
	private String tag_name2;
	private String tag_name3;

	private String member_image;
	// 객체관리
	private MultipartFile upFile;

	public int getTag_id1() {
		return tag_id1;
	}

	public void setTag_id1(int tag_id1) {
		this.tag_id1 = tag_id1;
	}

	public int getTag_id2() {
		return tag_id2;
	}

	public void setTag_id2(int tag_id2) {
		this.tag_id2 = tag_id2;
	}

	public int getTag_id3() {
		return tag_id3;
	}

	public void setTag_id3(int tag_id3) {
		this.tag_id3 = tag_id3;
	}

	public MultipartFile getUpFile() {
		return upFile;
	}

	public void setUpFile(MultipartFile upFile) {
		this.upFile = upFile;
	}

	public int getPost_id() {
		return post_id;
	}

	public void setPost_id(int post_id) {
		this.post_id = post_id;
	}

	public String getPost_title() {
		return post_title;
	}

	public void setPost_title(String post_title) {
		this.post_title = post_title;
	}

	public String getPost_content() {
		return post_content;
	}

	public void setPost_content(String post_content) {
		this.post_content = post_content;
	}

	public String getPost_time() {
		return post_time;
	}

	public void setPost_time(String post_time) {
		this.post_time = post_time;
	}

	public int getHobby_id() {
		return hobby_id;
	}

	public void setHobby_id(int hobby_id) {
		this.hobby_id = hobby_id;
	}

	public int getPost_like() {
		return post_like;
	}

	public void setPost_like(int post_like) {
		this.post_like = post_like;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPost_image() {
		return post_image;
	}

	public void setPost_image(String post_image) {
		this.post_image = post_image;
	}

	public String getTag_name1() {
		return tag_name1;
	}

	public void setTag_name1(String tag_name1) {
		this.tag_name1 = tag_name1;
	}

	public String getTag_name2() {
		return tag_name2;
	}

	public void setTag_name2(String tag_name2) {
		this.tag_name2 = tag_name2;
	}

	public String getTag_name3() {
		return tag_name3;
	}

	public void setTag_name3(String tag_name3) {
		this.tag_name3 = tag_name3;
	}

	public String getMember_image() {
		return member_image;
	}

	public void setMember_image(String member_image) {
		this.member_image = member_image;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Post [post_id=");
		builder.append(post_id);
		builder.append(", post_title=");
		builder.append(post_title);
		builder.append(", post_content=");
		builder.append(post_content);
		builder.append(", post_time=");
		builder.append(post_time);
		builder.append(", hobby_id=");
		builder.append(hobby_id);
		builder.append(", post_like=");
		builder.append(post_like);
		builder.append(", email=");
		builder.append(email);
		builder.append(", name=");
		builder.append(name);
		builder.append(", post_image=");
		builder.append(post_image);
		builder.append(", tag_id1=");
		builder.append(tag_id1);
		builder.append(", tag_id2=");
		builder.append(tag_id2);
		builder.append(", tag_id3=");
		builder.append(tag_id3);
		builder.append(", tag_name1=");
		builder.append(tag_name1);
		builder.append(", tag_name2=");
		builder.append(tag_name2);
		builder.append(", tag_name3=");
		builder.append(tag_name3);
		builder.append(", member_image=");
		builder.append(member_image);
		builder.append(", upFile=");
		builder.append(upFile);
		builder.append("]");
		return builder.toString();
	}



}
