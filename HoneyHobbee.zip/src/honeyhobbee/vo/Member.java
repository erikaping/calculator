package honeyhobbee.vo;

import java.sql.Date;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class Member {
	private String email;
	private String name;
	private String password;
	private Date birthday;
	private int job;
	private int gender;
	private String image;
	private int hobby1;
	private int hobby2;
	private int hobby3;

	// 객체관리
	private MultipartFile upFile;

	
	
	public MultipartFile getUpFile() {
		return upFile;
	}

	public void setUpFile(MultipartFile upFile) {
		this.upFile = upFile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public int getJob() {
		return job;
	}

	public void setJob(int job) {
		this.job = job;
	}

	public int getGender() {
		return gender;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public int getHobby1() {
		return hobby1;
	}

	public void setHobby1(int hobby1) {
		this.hobby1 = hobby1;
	}

	public int getHobby2() {
		return hobby2;
	}

	public void setHobby2(int hobby2) {
		this.hobby2 = hobby2;
	}

	public int getHobby3() {
		return hobby3;
	}

	public void setHobby3(int hobby3) {
		this.hobby3 = hobby3;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Member [email=");
		builder.append(email);
		builder.append(", name=");
		builder.append(name);
		builder.append(", password=");
		builder.append(password);
		builder.append(", birthday=");
		builder.append(birthday);
		builder.append(", job=");
		builder.append(job);
		builder.append(", gender=");
		builder.append(gender);
		builder.append(", image=");
		builder.append(image);
		builder.append(", hobby1=");
		builder.append(hobby1);
		builder.append(", hobby2=");
		builder.append(hobby2);
		builder.append(", hobby3=");
		builder.append(hobby3);
		builder.append("]");
		return builder.toString();
	}

}
