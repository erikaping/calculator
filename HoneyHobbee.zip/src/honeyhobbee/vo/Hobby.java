package honeyhobbee.vo;

import org.springframework.stereotype.Component;

@Component
public class Hobby {
	private int hobby_id;
	private String hobby_name;
	private String hobby_content;
	private int tag_id1;
	private int tag_id2;
	private int tag_id3;
	private String email;
	//추가
	private String tag_name1;
	private String tag_name2;
	private String tag_name3;
	private String name;
	
	
	
	public int getHobby_id() {
		return hobby_id;
	}

	public void setHobby_id(int hobby_id) {
		this.hobby_id = hobby_id;
	}

	public String getHobby_name() {
		return hobby_name;
	}

	public void setHobby_name(String hobby_name) {
		this.hobby_name = hobby_name;
	}

	public String getHobby_content() {
		return hobby_content;
	}

	public void setHobby_content(String hobby_content) {
		this.hobby_content = hobby_content;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getTag_id1() {
		return tag_id1;
	}

	public void setTag_id1(int tag_id1) {
		this.tag_id1 = tag_id1;
	}

	public int getTag_id2() {
		return tag_id2;
	}

	public void setTag_id2(int tag_id2) {
		this.tag_id2 = tag_id2;
	}

	public int getTag_id3() {
		return tag_id3;
	}

	public void setTag_id3(int tag_id3) {
		this.tag_id3 = tag_id3;
	}
	
	public String getTag_name1() {
		return tag_name1;
	}

	public void setTag_name1(String tag_name1) {
		this.tag_name1 = tag_name1;
	}

	public String getTag_name2() {
		return tag_name2;
	}

	public void setTag_name2(String tag_name2) {
		this.tag_name2 = tag_name2;
	}

	public String getTag_name3() {
		return tag_name3;
	}

	public void setTag_name3(String tag_name3) {
		this.tag_name3 = tag_name3;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Hobby [hobby_id=");
		builder.append(hobby_id);
		builder.append(", hobby_name=");
		builder.append(hobby_name);
		builder.append(", hobby_content=");
		builder.append(hobby_content);
		builder.append(", tag_id1=");
		builder.append(tag_id1);
		builder.append(", tag_id2=");
		builder.append(tag_id2);
		builder.append(", tag_id3=");
		builder.append(tag_id3);
		builder.append(", email=");
		builder.append(email);
		builder.append(", tag_name1=");
		builder.append(tag_name1);
		builder.append(", tag_name2=");
		builder.append(tag_name2);
		builder.append(", tag_name3=");
		builder.append(tag_name3);
		builder.append(", name=");
		builder.append(name);
		builder.append("]");
		return builder.toString();
	}

}
