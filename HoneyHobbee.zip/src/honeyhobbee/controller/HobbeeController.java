package honeyhobbee.controller;

import honeyhobbee.dao.iHobbeeDao;
import honeyhobbee.dao.iMemberDao;
import honeyhobbee.dao.iPostDao;
import honeyhobbee.vo.Hobby;
import honeyhobbee.vo.Job;
import honeyhobbee.vo.Member;
import honeyhobbee.vo.Post;
import honeyhobbee.vo.Tag;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HobbeeController {

	@Autowired
	iHobbeeDao hDao;
	@Autowired
	iMemberDao mDao;
	@Autowired
	iPostDao pDao;

	// honeyhobbee 메인
	@RequestMapping("honeyhobbee.do")
	public String honeyhobbee(Model model) {

		List<Post> postList = new ArrayList<Post>();
		ArrayList<Tag> tagList = new ArrayList<Tag>();

		postList = pDao.selectAllPost();

		/*
		 * for (Post post : postList) { post.setTag_name1();
		 * post.setTag_name2(); post.setTag_name3(); }
		 */

		// hDao.selectAllTag();

		model.addAttribute("postList", postList);
		model.addAttribute("content", "jsp/hobbeeList.jsp");

		return "index.jsp";
	}

	@RequestMapping("insertHobbee.do")
	private String hobbeeInsert(Model model, Hobby h, HttpSession s) {

		// 등록한 사용자의 세션아이디를 받아 pioneer로 등록하는 부분
		String email = (String) s.getAttribute("email");
		String name = (String) s.getAttribute("name");
		h.setEmail(email);
		h.setName(name);
		List<Hobby> hobbeeList = new ArrayList<Hobby>();

		System.out.println("insertHobby: " + h);

		// 태그 아이디를 받아 태그의 이름을 찾고 다시 넣어주는 부분
		h.setTag_name1(hDao.selectTagName(h.getTag_id1()));
		h.setTag_name2(hDao.selectTagName(h.getTag_id2()));
		h.setTag_name3(hDao.selectTagName(h.getTag_id3()));

		hDao.insertHobby(h);
		hobbeeList = hDao.selectAllHobby();
		model.addAttribute("hobbeeList", hobbeeList);

		model.addAttribute("content", "jsp/hobbeeBlocks.jsp");
		return "index.jsp";
	}

	@RequestMapping("selectMemberPost.do")
	public String selectMemberPostList(Model model,
			@RequestParam("email") String email) {

		Member m = mDao.searchEmail(email);
		List<Post> postList = pDao.selectPostList(email);
		model.addAttribute("postList", postList);

		model.addAttribute("content", "jsp/hobbeeList.jsp");
		return "index.jsp";
	}

	// 지윤이가 했다
	@RequestMapping("selectTaghobbeeBlock.do")
	public String selectTaghobbeeBlock(Model model,
			@RequestParam("tag_id") int tag_id) {

		List<Hobby> hobbeeList = new ArrayList<Hobby>();

		hobbeeList = hDao.selectHobby(tag_id);
		model.addAttribute("hobbeeList", hobbeeList);

		model.addAttribute("content", "jsp/hobbeeBlocks.jsp");
		return "index.jsp";
	}

	@RequestMapping("hobbeeInsertPage.do")
	public String hobbeeInsertPage(Model model, HttpSession s) {

		String email = (String) s.getAttribute("email");
		String name = (String) s.getAttribute("name");
		List<Tag> tagList1 = new ArrayList<Tag>();
		List<Tag> tagList2 = new ArrayList<Tag>();
		List<Tag> tagList3 = new ArrayList<Tag>();

		tagList1 = hDao.selectTagList(1);
		tagList2 = hDao.selectTagList(2);
		tagList3 = hDao.selectTagList(3);

		model.addAttribute("email", email);
		model.addAttribute("name", name);
		model.addAttribute("tagList1", tagList1);
		model.addAttribute("tagList2", tagList2);
		model.addAttribute("tagList3", tagList3);

		model.addAttribute("content", "jsp/hobbeeInsert.jsp");
		return "index.jsp";
	}

	// 지윤이가 했다
	// 블럭 페이지로 이동
	@RequestMapping("hobbeeBlock.do")
	public String hobbeeBlock(Model model) {

		List<Hobby> hobbeeList = new ArrayList<Hobby>();

		hobbeeList = hDao.selectAllHobby();
		model.addAttribute("hobbeeList", hobbeeList);

		model.addAttribute("content", "jsp/hobbeeBlocks.jsp");
		return "index.jsp";
	}

	@RequestMapping("selectHobbeeBymyGen.do")
	public String selectHobbeeBymyGen(Model model, HttpSession session) {

		List<Hobby> hobbeeList = new ArrayList<Hobby>();

		String email = (String) session.getAttribute("email");
		Member member = mDao.searchEmail(email);
		int gen = member.getGender();
		String yourGen = null;

		if (gen == 1) {
			yourGen = "남자분";
		} else if (gen == 2) {
			yourGen = "여자분";
		}

		hobbeeList = hDao.selectHobbeeBymyGen(gen);
		model.addAttribute("hobbeeList", hobbeeList);

		model.addAttribute("yourGen", yourGen);

		model.addAttribute("content", "jsp/hobbeeBlocks.jsp");
		return "index.jsp";
	}

	@RequestMapping("selectHobbeeBymyJob.do")
	public String selectHobbeeBymyJob(Model model, HttpSession session) {

		List<Hobby> hobbeeList = new ArrayList<Hobby>();

		String email = (String) session.getAttribute("email");
		Member member = mDao.searchEmail(email);
		int job_id = member.getJob();
		String yourJob = null;

		List<Job> jobList = hDao.selectAllJob();

		for (Job job : jobList) {
			if (job.getJob_id() == job_id) {
				yourJob = job.getJob_name();
			}
		}

		hobbeeList = hDao.selectHobbeeBymyJob(job_id);
		model.addAttribute("hobbeeList", hobbeeList);

		model.addAttribute("yourJob", yourJob);

		model.addAttribute("content", "jsp/hobbeeBlocks.jsp");
		return "index.jsp";
	}

}
