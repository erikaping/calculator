package honeyhobbee.controller;

import honeyhobbee.dao.HobbeeDao;
import honeyhobbee.dao.MemberDao;
import honeyhobbee.dao.PostDao;
import honeyhobbee.dao.iHobbeeDao;
import honeyhobbee.dao.iMemberDao;
import honeyhobbee.dao.iPostDao;
import honeyhobbee.vo.Hobby;
import honeyhobbee.vo.Job;
import honeyhobbee.vo.Member;
import honeyhobbee.vo.Post;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class MemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	iMemberDao mDao;
	iPostDao pDao;
	iHobbeeDao hDao;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");

		String action = request.getParameter("action");
		String content = null; // 주소값

//		if (action == null) {
//			content = honeyhobbee(request, response);
//		}
//		if ("LOGIN".equals(action)) {
//			content = login(request, response);
//		} else if ("LOGOUT".equals(action)) {
//			logout(request, response);
//		} else if ("JOINPAGE".equals(action)) {
//			content = joinPage(request, response);
//		} else if ("HONEYHOBBEE".equals(action)) {
//			content = honeyhobbee(request, response);
//		} else if ("JOIN".equals(action)) {
//			content = join(request, response);
//		} else if ("EMAILCHECK".equals(action)) {
//			emailCheck(request, response);
//		} else if ("MYPAGE".equals(action)) {
//			content = myPage(request, response);
//		} else if ("UPDATEMEMBER".equals(action)) {
//			content = updateMember(request, response);
//		} else if ("DELETEMEMBER".equals(action)) {
//			deleteMember(request, response);
//		}
//
//		if (content != null) {
//			request.setAttribute("content", content);
//			request.getRequestDispatcher("index.jsp")
//					.forward(request, response);
//		}

	}// end of doPost

/*	// 회원 탈퇴
	private void deleteMember(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		mDao = new MemberDao();
		String email = (String) request.getSession().getAttribute("email");

		try {
			mDao.deleteMember(email);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		request.getRequestDispatcher("main.jsp").forward(request, response);
		return;
	}

	// 회원정보 수정
	private String updateMember(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		mDao = new MemberDao();

		String saveDir = "images";
		String saveFullDir = getServletContext().getRealPath(saveDir);
		int maxFileSize = 5 * 1024 * 1024;
		String encoding = "utf-8";
		MultipartRequest mRequest = null;
		try {
			mRequest = new MultipartRequest(request, saveFullDir, maxFileSize,
					encoding, new DefaultFileRenamePolicy());

			String email = (String) request.getSession().getAttribute("email");
			String name = mRequest.getParameter("name");
			String password = mRequest.getParameter("password");
			int job =Integer.parseInt(mRequest.getParameter("job"));
			String image = mRequest.getFilesystemName("image");
			String hobbee1 = mRequest.getParameter("hobby1");
			String hobbee2 = mRequest.getParameter("hobby2");
			String hobbee3 = mRequest.getParameter("hobby3");

			int hobby1 = Integer.parseInt(hobbee1);
			int hobby2 = Integer.parseInt(hobbee2);
			int hobby3 = Integer.parseInt(hobbee3);

			Member m = mDao.searchEmail(email);
			mDao.updateMember(new Member(m.getEmail(), name, password, m
					.getBirthday(), job , m.getGender(), image, hobby1, hobby2,
					hobby3));
			request.getSession().setAttribute("name", name);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return myPage(request, response);
	}

	// 마이페이지로 이동
	private String myPage(HttpServletRequest request,
			HttpServletResponse response) {
		String content = "jsp/mypage.jsp";

		mDao = new MemberDao();
		HttpSession s = request.getSession();
		String email = (String) s.getAttribute("email");
		String name = (String) s.getAttribute("name");

		hDao = new HobbeeDao();
		List<Job> jobList = new ArrayList<Job>();
		List<Hobby> hobbyList = new ArrayList<Hobby>();

		try {
			Member m = mDao.searchEmail(email);
			jobList = hDao.selectAllJob();
			hobbyList = hDao.selectAllHobby();

			request.setAttribute("m", m);
			request.setAttribute("jobList", jobList);
			request.setAttribute("hobbyList", hobbyList);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return content;
	}

	// 이메일 중복확인
	private void emailCheck(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		mDao = new MemberDao();
		String email = request.getParameter("email");
		boolean isDupl = false;
		System.out.println("email: " + email);
		try {
			if (email != null) {
				Member m = mDao.searchEmail(email);
				request.setAttribute("email", email);
				if (m != null) {
					isDupl = true;
					request.setAttribute("isDupl", isDupl);
					request.getRequestDispatcher("jsp/duplicate.jsp").forward(
							request, response);
					return;
				} else {
					request.setAttribute("isDupl", isDupl);
					request.getRequestDispatcher("jsp/duplicate.jsp").forward(
							request, response);
					return;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	// 회원가입 페이지로 이동
	private String joinPage(HttpServletRequest request,
			HttpServletResponse response) {
		String content = null;
		hDao = new HobbeeDao();
		List<Job> jobList = new ArrayList<Job>();
		List<Hobby> hobbyList = new ArrayList<Hobby>();
		try {
			jobList = hDao.selectAllJob();
			hobbyList = hDao.selectAllHobby();
			request.setAttribute("jobList", jobList);
			request.setAttribute("hobbyList", hobbyList);
			content = "jsp/join.jsp";
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return content;
	}

	// 회원 가입
	private String join(HttpServletRequest request, HttpServletResponse response) {
		mDao = new MemberDao();
		HttpSession s = request.getSession();
		String email = request.getParameter("email");
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		Date birthday = Date.valueOf(request.getParameter("birthday"));
		String job = request.getParameter("job");
		// String image = request.getParameter("image");
		String hobbee1 = request.getParameter("hobby1");
		String hobbee2 = request.getParameter("hobby2");
		String hobbee3 = request.getParameter("hobby3");
		String gender = request.getParameter("gender");

		int hobby1 = Integer.parseInt(hobbee1);
		int hobby2 = Integer.parseInt(hobbee2);
		int hobby3 = Integer.parseInt(hobbee3);

		try {
			Member m = new Member(email, name, password, birthday,Integer.parseInt(job),
					Integer.parseInt(gender), hobby1, hobby2, hobby3);
			mDao.insertMember(m);
			s.setAttribute("email", m.getEmail());
			s.setAttribute("name", m.getName());
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return honeyhobbee(request, response);
	}

	// honeyhobbee 메인
	private String honeyhobbee(HttpServletRequest request,
			HttpServletResponse response) {
		String content = null;
		pDao = new PostDao();
		List<Post> postList = new ArrayList<Post>();
		try {
			postList = pDao.selectAllPost();
			request.setAttribute("postList", postList);
			content = "jsp/hobbeeList.jsp";
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return content;
	}

	// 로그아웃
	private void logout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession s = request.getSession(false); // 세션이 있으면 가져옴

		if (s != null) {
			s.invalidate(); // 세션 비활성화
		}
		request.getRequestDispatcher("main.jsp").forward(request, response);
		return;
	}

	// 로그인
	private String login(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String content = null;
		mDao = new MemberDao();

		try {
			Member m = mDao.login(email, password);
			System.out.println(m);
			// 아이디와 비밀번호가 맞은 경우
			if (m != null) {
				// 세션에 email과 name 넣어둠
				HttpSession s = request.getSession();
				s.setAttribute("email", email);
				s.setAttribute("name", m.getName());
				content = honeyhobbee(request, response); // 메인화면으로
			} else {
				request.setAttribute("message", "아이디 또는 비밀번호가 틀렸습니다.");
				request.getRequestDispatcher("main.jsp").forward(request,
						response);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return content;
	}
*/
}
