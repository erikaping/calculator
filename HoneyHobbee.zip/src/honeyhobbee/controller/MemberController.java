package honeyhobbee.controller;

import honeyhobbee.dao.iHobbeeDao;
import honeyhobbee.dao.iMemberDao;
import honeyhobbee.dao.iPostDao;
import honeyhobbee.vo.Hobby;
import honeyhobbee.vo.Job;
import honeyhobbee.vo.Member;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class MemberController {

	@Autowired
	iMemberDao mDao;
	@Autowired
	iPostDao pDao;
	@Autowired
	iHobbeeDao hDao;

	// 회원정보수정
	@RequestMapping("updateMember.do")
	public String updateMember(Member m) throws IOException {

		System.out.println("ctrl updateMember" + m);

		// 파일 업로드
		MultipartFile uploadFile = m.getUpFile();
		String fileName = null;
		if (uploadFile != null && uploadFile.getOriginalFilename().length() > 0) {
			fileName = uploadFile.getOriginalFilename();
			byte[] fileData = uploadFile.getBytes();
			FileOutputStream output = new FileOutputStream(
					"C:/JavaWorks/HoneyHobbee/WebContent/memImage/" + fileName);

			System.out.println("filename : " + fileName);
			output.write(fileData);
			output.close();
		}
		m.setImage(fileName);

		mDao.updateMember(m);

		return "mypage.do";
	}

	// 회원 탈퇴
	@RequestMapping("deleteMember.do")
	public String deleteMember(Model model, HttpSession session)
			throws ServletException, IOException {

		String email = (String) session.getAttribute("email");

		mDao.deleteMember(email);

		model.addAttribute("content", "main.jsp");
		return "index.jsp";
	}

	// myPage로 이동
	@RequestMapping("mypage.do")
	public String myPage(Model model, HttpSession s) {

		String email = (String) s.getAttribute("email");
		String name = (String) s.getAttribute("name");

		System.out.println("email : " + email);
		System.out.println("name : " + name);

		List<Job> jobList = new ArrayList<Job>();
		List<Hobby> hobbyList = new ArrayList<Hobby>();

		Member m = mDao.searchEmail(email);
		jobList = hDao.selectAllJob();
		hobbyList = hDao.selectAllHobby();

		model.addAttribute("m", m);

		model.addAttribute("jobList", jobList);
		model.addAttribute("hobbyList", hobbyList);

		model.addAttribute("content", "jsp/mypage.jsp");
		return "index.jsp";
	}

	// 이메일 중복확인
	@RequestMapping("emailCheck.do")
	public String emailCheck(Model model, HttpServletRequest request,
			HttpServletResponse response) {

		String email = request.getParameter("email");
		boolean isDupl = false;

		if (email != null) {
			Member m = mDao.searchEmail(email);
			model.addAttribute("email", email);
			if (m != null) {
				isDupl = true;
				model.addAttribute("isDupl", isDupl);
				return "jsp/duplicate.jsp";
			} else {
				model.addAttribute("isDupl", isDupl);
				return "jsp/duplicate.jsp";
			}
		}

		return "jsp/duplicate.jsp";
	}

	// 회원 가입
	@RequestMapping("join.do")
	public String join(HttpSession session, @RequestParam("bday") String bday,
			Member m) {

		System.out.println("join.do");
		m.setBirthday(Date.valueOf(bday));

		mDao.insertMember(m);

		session.setAttribute("email", m.getEmail());
		session.setAttribute("name", m.getName());

		return "honeyhobbee.do";
	}

	// 회원가입 페이지로 이동
	@RequestMapping("joinPage.do")
	public String joinPage(Model model) {

		List<Job> jobList = new ArrayList<Job>();
		List<Hobby> hobbyList = new ArrayList<Hobby>();

		jobList = hDao.selectAllJob();
		hobbyList = hDao.selectAllHobby();
		model.addAttribute("jobList", jobList);
		model.addAttribute("hobbyList", hobbyList);

		model.addAttribute("content", "jsp/join.jsp");

		return "index.jsp";
	}

	@RequestMapping("login.do")
	public String login(Model model, Member m, HttpSession session) {

		String email = m.getEmail();
		String password = m.getPassword();

		Member member = null;

		member = mDao.login(m);

		// 아이디와 비밀번호가 맞은 경우
		if (member != null) {
			// 세션에 email과 name 넣어둠
			session.setAttribute("email", email);
			session.setAttribute("name", member.getName());

			return "honeyhobbee.do";
		} else {
			model.addAttribute("message", "아이디 또는 비밀번호가 틀렸습니다.");
			model.addAttribute("content", "main.jsp");
			return "index.jsp";
		}

	}

	@RequestMapping("logout.do")
	public String logout(Model model, Member m, HttpSession session) {

		session.invalidate();
		model.addAttribute("content", "main.jsp");
		return "index.jsp";
	}

	// 이메일 찾기
	@RequestMapping("findEmail.do")
	public String findEmail(Model model, Member m,
			@RequestParam("bday") String bDay, HttpSession session) {
		m.setBirthday(Date.valueOf(bDay));
		String email = mDao.findEmail(m);
		model.addAttribute("tmpEmail", email);
		System.out.println("ctrl return email " + email);

		return "/jsp/closeThis.jsp";
	}

	// 비밀번호 찾기
	@RequestMapping("findPassword.do")
	public String findPassword(Model model, Member m,
			@RequestParam("bday") String bDay, HttpSession session) {
		m.setBirthday(Date.valueOf(bDay));
		String tmpPassword = mDao.findPassword(m);
		model.addAttribute("tmpPassword", tmpPassword);
		System.out.println("ctrl return email " + tmpPassword);

		return "/jsp/closeThis.jsp";
	}

}
