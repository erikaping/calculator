package honeyhobbee.controller;

import honeyhobbee.dao.iHobbeeDao;
import honeyhobbee.dao.iMemberDao;
import honeyhobbee.dao.iPostDao;
import honeyhobbee.vo.Hobby;
import honeyhobbee.vo.Post;
import honeyhobbee.vo.Tag;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class PostController {

	@Autowired
	iMemberDao mDao;
	@Autowired
	iPostDao pDao;
	@Autowired
	iHobbeeDao hDao;

	@RequestMapping("selectHobbeePostList.do")
	public String selectHobbeePostList(Model model,
			@RequestParam("hobby_id") int hobby_id) {

		List<Post> postList = pDao.selectPostListByHobby_id(hobby_id);
		model.addAttribute("postList", postList);

		model.addAttribute("content", "jsp/hobbeeList.jsp");
		return "index.jsp";
	}

	@RequestMapping("selectHobbeePost.do")
	public String selectHobbeePost(Model model,
			@RequestParam("hobby_id") int hobby_id) {

		List<Post> postList = pDao.selectPostListByHobby_id(hobby_id);
		model.addAttribute("postList", postList);
		model.addAttribute("content", "jsp/hobbeeList.jsp");
		return "index.jsp";
	}

	@RequestMapping("selectTagsPosts.do")
	public String selectTagsPosts(Model model,
			@RequestParam("tag_id") int tag_id) {

		List<Post> postList = pDao.selectTagsPosts(tag_id);
		model.addAttribute("postList", postList);

		model.addAttribute("content", "jsp/hobbeeList.jsp");
		return "index.jsp";
	}

	@RequestMapping("post_popup.do")
	public String post_popup(Model model, HttpSession session) {

		String email = (String) session.getAttribute("email");
		String name = (String) session.getAttribute("name");

		List<Hobby> hobbyList = new ArrayList<Hobby>();

		hobbyList = hDao.selectAllHobby();
		model.addAttribute("hobbyList", hobbyList);

		model.addAttribute("email", email);
		model.addAttribute("name", name);

		return "jsp/postInsert.jsp";
	}

	@RequestMapping("postLike.do")
	public String postLike(Model model, @RequestParam("post_id") int post_id) {
		pDao.likePost(post_id);
		return "honeyhobbee.do";
	}

	@RequestMapping("deletePost.do")
	private String deletePost(Model model, @RequestParam("post_id") int post_id) {

		pDao.deletePost(post_id);
		List<Post> postList = pDao.selectAllPost();
		model.addAttribute("postList", postList);

		model.addAttribute("content", "jsp/hobbeeList.jsp");
		return "index.jsp";
	}

	@RequestMapping("updatePost.do")
	public String updatePost(Model model, Post post) {

		System.out.println("ctrl 에서 만난 postUpdate" + post);
		pDao.updatePost(post);

		return "jsp/postUpdate.jsp";
	}

	@RequestMapping("gotoUpatePost.do")
	public String gotoUpatePost(Model model, HttpSession session,
			@RequestParam("post_id") int post_id) {

		String email = (String) session.getAttribute("email");
		String name = (String) session.getAttribute("name");

		List<Hobby> hobbyList = new ArrayList<Hobby>();
		try {

			Post post = pDao.selectPost(post_id);
			model.addAttribute("post", post);
			hobbyList = hDao.selectAllHobby();
			model.addAttribute("hobbyList", hobbyList);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		model.addAttribute("email", email);
		model.addAttribute("name", name);
		model.addAttribute("post_id", post_id);

		return "jsp/postUpdate.jsp";
	}

	@RequestMapping(value = "insertPost.do", method = RequestMethod.POST)
	public String insertPost(Model model, Post p) throws IOException {

		System.out.println("controller p : " + p);
		// 파일 업로드
		MultipartFile uploadFile = p.getUpFile();
		String fileName = null;
		if (uploadFile != null && uploadFile.getOriginalFilename().length() > 0) {
			fileName = uploadFile.getOriginalFilename();
			byte[] fileData = uploadFile.getBytes();
			FileOutputStream output = new FileOutputStream(
					"C:/JavaWorks/HoneyHobbee/WebContent/downImage/" + fileName);

			System.out.println("filename : " + fileName);
			output.write(fileData);
			output.close();
		}
		p.setPost_image(fileName);

		// 등록한 사용자를 받아서 사용자의 이미지를 넣어주는 곳
		String member_image = mDao.searchEmail(p.getEmail()).getImage();
		System.out.println("member_image:" + member_image);
		p.setMember_image(member_image);

		int hobby_id = p.getHobby_id();

		List<Tag> tagList = hDao.selectTagListByHobbyid(hobby_id);

		p.setTag_id1(tagList.get(0).getTag_id());
		p.setTag_id2(tagList.get(1).getTag_id());
		p.setTag_id3(tagList.get(2).getTag_id());

		p.setTag_name1(tagList.get(0).getTag_name());
		p.setTag_name2(tagList.get(1).getTag_name());
		p.setTag_name3(tagList.get(2).getTag_name());

		pDao.insertPost(p);

		return "jsp/closeThis.jsp";
	}

}
