package honeyhobbee.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import honeyhobbee.dao.HobbeeDao;
import honeyhobbee.dao.MemberDao;
import honeyhobbee.dao.PostDao;
import honeyhobbee.dao.iHobbeeDao;
import honeyhobbee.dao.iMemberDao;
import honeyhobbee.dao.iPostDao;
import honeyhobbee.vo.Hobby;
import honeyhobbee.vo.Member;
import honeyhobbee.vo.Post;
import honeyhobbee.vo.Tag;

@Controller
public class AdminController {

	@Autowired
	iMemberDao mDao;
	@Autowired
	iPostDao pDao;
	@Autowired
	iHobbeeDao hDao;

	@RequestMapping("deletePostbyAdmin.do")
	public String deletePostbyAdmin(Model model,
			@RequestParam("post_id") int post_id) {

		pDao.deletePost(post_id);

		List<Post> postList = pDao.selectAllPost();
		model.addAttribute("postList", postList);

		model.addAttribute("content", "jsp/adminPostList.jsp");
		return "index.jsp";
	}

	@RequestMapping("deleteMemberByAmdin.do")
	private String deleteMember(Model model, @RequestParam("email") String email) {

		mDao.deleteMember(email);
		List<Member> memberList = mDao.searchAllMember();
		model.addAttribute("memberList", memberList);

		model.addAttribute("content", "jsp/memberList.jsp");
		return "index.jsp";
	}

	@RequestMapping("selectMemberPostList.do")
	public String selectMemberPostList(Model model,
			@RequestParam("email") String email) {

		List<Post> postList = pDao.selectPostList(email);
		model.addAttribute("postList", postList);

		model.addAttribute("content", "jsp/adminPostList.jsp");
		return "index.jsp";
	}

	@RequestMapping("memberList.do")
	public String memberList(Model model) {

		List<Member> memberList = mDao.searchAllMember();
		model.addAttribute("memberList", memberList);

		model.addAttribute("content", "jsp/memberList.jsp");
		return "index.jsp";
	}

	@RequestMapping("hobbeeListbyAdmin.do")
	public String hobbeeList(Model model) {

		List<Hobby> hobbeeList = hDao.selectAllHobby();
		model.addAttribute("hobbeeList", hobbeeList);

		model.addAttribute("content", "jsp/adminHobbeList.jsp");
		return "index.jsp";
	}

	@RequestMapping("hobbeeinsertpage.do")
	public String hobbeeinsertpage(Model model, HttpSession s) {

		String email = (String) s.getAttribute("email");
		String name = (String) s.getAttribute("name");

		List<Tag> tagList1 = new ArrayList<Tag>();
		List<Tag> tagList2 = new ArrayList<Tag>();
		List<Tag> tagList3 = new ArrayList<Tag>();

		tagList1 = hDao.selectTagList(1);
		tagList2 = hDao.selectTagList(2);
		tagList3 = hDao.selectTagList(3);

		model.addAttribute("email", email);
		model.addAttribute("name", name);
		model.addAttribute("tagList1", tagList1);
		model.addAttribute("tagList2", tagList2);
		model.addAttribute("tagList3", tagList3);

		model.addAttribute("content", "jsp/hobbeeInsert.jsp");
		return "index.jsp";
	}

	@RequestMapping("postListbyAdmin.do")
	public String postList(Model model) {

		List<Post> postList = pDao.selectAllPost();
		model.addAttribute("postList", postList);

		model.addAttribute("content", "jsp/adminPostList.jsp");
		return "index.jsp";
	}

	@RequestMapping("tagList.do")
	public String tagList(Model model) {

		List<Tag> tagList = hDao.selectAllTag();
		model.addAttribute("tagList", tagList);

		model.addAttribute("content", "jsp/tagList.jsp");
		return "index.jsp";
	}

	@RequestMapping("insertTag.do")
	public String insertTag(Model model, Tag tag) {

		try {

			hDao.insertTag(tag);

			List<Tag> tagList = hDao.selectAllTag();
			model.addAttribute("tagList", tagList);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("content", "jsp/tagList.jsp");
		return "index.jsp";
	}

	@RequestMapping("deleteTag.do")
	public String deleteTag(Model model, @RequestParam("tag_id") int tag_id) {

		try {
			System.out.println(tag_id);
			hDao.deleteTag(tag_id);
			List<Tag> tagList = hDao.selectAllTag();
			model.addAttribute("tagList", tagList);

		} catch (SQLException e) {
			e.printStackTrace();

		}
		model.addAttribute("content", "jsp/tagList.jsp");
		return "index.jsp";
	}

}
