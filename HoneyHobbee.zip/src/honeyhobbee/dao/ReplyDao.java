package honeyhobbee.dao;

import honeyhobbee.util.DBUtil;
import honeyhobbee.vo.Reply;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("replyDAO")
public class ReplyDao implements iReplyDao {
	
		// reply 등록
		/* (non-Javadoc)
		 * @see honeyhobbee.dao.iReplyDao#insertReply(honeyhobbee.vo.Reply)
		 */
		@Override
		public void insertReply(Reply r) throws SQLException {
			Connection con = null;
			PreparedStatement ps = null;
			try {
				con = DBUtil.getConnection();
				String sql = "insert into reply values(reply_seq.NEXTVAL,?,sysdate,?,?)";
				ps = con.prepareStatement(sql);

				ps.setInt(1, r.getPost_id());
				ps.setString(2, r.getEmail());
				ps.setString(3, r.getReply_content());

				ps.executeUpdate();
			} finally {
				DBUtil.close(ps);
				DBUtil.close(con);
			}
		}
		
		//reply 수정
		/* (non-Javadoc)
		 * @see honeyhobbee.dao.iReplyDao#updateReply(honeyhobbee.vo.Reply)
		 */
		@Override
		public void updateReply(Reply r) throws SQLException{
			Connection con = null;
			PreparedStatement ps = null;
			try {
				con = DBUtil.getConnection();
				String sql = "update reply set reply_time=sysdate, reply_content=? where reply_id=?";
				ps = con.prepareStatement(sql);
			
				ps.setString(1, r.getReply_content());
				ps.setInt(2, r.getReply_id());
				
				ps.executeUpdate();
			} finally {
				DBUtil.close(ps);
				DBUtil.close(con);
			}
		}
		
		//reply 삭제
		/* (non-Javadoc)
		 * @see honeyhobbee.dao.iReplyDao#deleteReply(honeyhobbee.vo.Reply)
		 */
		@Override
		public void deleteReply(Reply r) throws SQLException{
			Connection con = null;
			PreparedStatement ps = null;
			try {
				con = DBUtil.getConnection();
				String q = "delete from reply where reply_id=?";
				ps = con.prepareStatement(q);
				ps.setInt(1, r.getReply_id());
				ps.executeUpdate();
			} finally {
				DBUtil.close(ps);
				DBUtil.close(con);
			}
		}
		
		//reply 조회
		/* (non-Javadoc)
		 * @see honeyhobbee.dao.iReplyDao#selectAllReply(int)
		 */
		@Override
		public List<Reply> selectAllReply(int post_id) throws SQLException{
			/*Connection con = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			Reply r = null;
			List<Reply> list = new ArrayList<Reply>();
			try {
				con = DBUtil.getConnection();

				String sql = "select * from post order by post_id desc";
				ps = con.prepareStatement(sql);

				rs = ps.executeQuery();
				while (rs.next()) {
					r = new Reply(rs.getInt(1), rs.getInt(2), rs.getString(3),
							rs.getString(5), rs.getString(6));
					list.add(r);
				}
			} finally {
				DBUtil.close(rs);
				DBUtil.close(ps);
				DBUtil.close(con);

			}
			return list;*/
			return null;
		}

}
