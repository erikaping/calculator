package honeyhobbee.dao;

import honeyhobbee.vo.Post;

import java.sql.SQLException;
import java.util.List;

public interface iPostDao {

	// post 등록
	public abstract void insertPost(Post p);

	// post 수정
	public abstract void updatePost(Post p);

	// post 삭제
	public abstract void deletePost(int post_id);

	// 전체 포스트 조회
	public abstract List<Post> selectAllPost();

	// 포스트 한 개 조회
	public abstract Post selectPost(int post_id) throws SQLException;

	// 한 사람이 쓴 포스트 전체 조회
	public abstract List<Post> selectPostList(String email);

	// 취미와 관련된 포스트 가져옴
	public abstract List<Post> selectPostListByHobby_id(int hobby_id);

	/*
	 * //취미와 관련된 태그네임가져옴 public abstract List<String> selectTagNameList(int
	 * hobby_id) throws SQLException;
	 */

	// 좋아요
	public abstract void likePost(int post_id);

	public abstract List<Post> selectTagsPosts(int tag_id);

}