package honeyhobbee.dao;

import honeyhobbee.vo.Hobby;
import honeyhobbee.vo.Job;
import honeyhobbee.vo.Tag;

import java.sql.SQLException;
import java.util.List;

public interface iHobbeeDao {

	// 취미 추가
	public abstract void insertHobby(Hobby h);

	// 취미 수정
	public abstract void updateHobby(Hobby h) throws SQLException;

	// 취미삭제
	public abstract void deletePost(Hobby h) throws SQLException;

	// 취미 전체 조회 //지윤이가 했다
	public abstract List<Hobby> selectAllHobby();

	// 태그 이름 조회
	public abstract String selectTagName(int tag_id);

	// 태그에 포함된 취미 조회(태그 한개) //지윤이가 했다
	public abstract List<Hobby> selectHobby(int tag_id);

	// 태그 추가
	public abstract void insertTag(Tag t) throws SQLException;

	// 태그 수정
	public abstract void updateTag(Tag t) throws SQLException;

	// 태그 조회
	public abstract List<Tag> selectAllTag();

	// 태그1, 2, 3 조회
	public abstract List<Tag> selectTagList(int num);

	// 직업 가져오기
	public abstract List<Job> selectAllJob();

	public abstract void deleteTag(int tag_id) throws SQLException;

	public abstract List<Tag> selectTagListByHobbyid(int hobby_id);

	public abstract List<Hobby> selectHobbeeBymyJob(int job_id);

	public abstract List<Hobby> selectHobbeeBymyGen(int gen);

}