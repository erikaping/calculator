package honeyhobbee.dao;

import honeyhobbee.vo.Member;

import java.sql.SQLException;
import java.util.List;

public interface iMemberDao {

	// 로그인
	public abstract Member login(Member m);

	// 회원가입
	public abstract void insertMember(Member m) ;

	// 회원정보 수정(이메일, 생일, 성별 빼고 변경가능)
	public abstract void updateMember(Member m) ;

	// 회원 탈퇴
	public abstract void deleteMember(String email) ;

	// 전체회원 조회
	public abstract List<Member> searchAllMember();

	// email로 회원 검색
	public abstract Member searchEmail(String email);

	// 회원 사진 가져옴
	public abstract String searchMemberImage(String email);

	public abstract String findEmail(Member m);

	public abstract String findPassword(Member m);

}