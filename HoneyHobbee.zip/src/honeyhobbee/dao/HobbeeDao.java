package honeyhobbee.dao;

import honeyhobbee.util.DBUtil;
import honeyhobbee.vo.Hobby;
import honeyhobbee.vo.Job;
import honeyhobbee.vo.Tag;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

//hobby, tag, job 테이블 관련 모든 작업
@Repository("hobbeeDAO")
public class HobbeeDao implements iHobbeeDao {

	@Autowired
	@Qualifier("sqlSession")
	private SqlSession myBatis;

	@Autowired
	MemberDao mDao;

	// 취미 추가
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iHobbeeDao#insertHobby(honeyhobbee.vo.Hobby)
	 */
	@Override
	public void insertHobby(Hobby h) {
		System.out.println("dao'ss insertHobby: " + h);
		myBatis.insert("insertHobby", h);

	}

	// 취미 수정
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iHobbeeDao#updateHobby(honeyhobbee.vo.Hobby)
	 */
	@Override
	public void updateHobby(Hobby h) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = DBUtil.getConnection();
			String sql = "update hobby set hobby_name=?, hobby_content=?, tag_id1=?,"
					+ " tag_id2=?, tag_id3=?, email=? " + " where hobby_id = ?";

			ps = con.prepareStatement(sql);
			ps.setString(1, h.getHobby_name());
			ps.setString(2, h.getHobby_content());
			ps.setInt(3, h.getTag_id1());
			ps.setInt(4, h.getTag_id2());
			ps.setInt(5, h.getTag_id3());
			ps.setString(6, h.getEmail());
			ps.setInt(7, h.getHobby_id());

			ps.executeUpdate();
		} finally {
			DBUtil.close(ps);
			DBUtil.close(con);
		}
	}

	// 취미삭제
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iHobbeeDao#deletePost(honeyhobbee.vo.Hobby)
	 */
	@Override
	public void deletePost(Hobby h) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = DBUtil.getConnection();
			String q = "delete from hobby where hobby_id=?";
			ps = con.prepareStatement(q);
			ps.setInt(1, h.getHobby_id());
			ps.executeUpdate();
		} finally {
			DBUtil.close(ps);
			DBUtil.close(con);
		}
	}

	// 취미 전체 조회
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iHobbeeDao#selectAllHobby()
	 */
	// 지윤이가 했다
	@Override
	public List<Hobby> selectAllHobby() {
		List<Hobby> selectList = new ArrayList<Hobby>();
		selectList = myBatis.selectList("selectAllHobby");
		return selectList;
	}
	
	@Override
	public List<Hobby> selectHobbeeBymyJob(int job_id) {
		List<Hobby> selectList = new ArrayList<Hobby>();
		selectList = myBatis.selectList("selectHobbeeBymyJob",job_id);
		return selectList;
	}
	

	@Override
	public List<Hobby> selectHobbeeBymyGen(int gen) {
		List<Hobby> selectList = new ArrayList<Hobby>();
		selectList = myBatis.selectList("selectHobbeeBymyGen",gen);
		return selectList;
	}

	// 태그 이름 조회
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iHobbeeDao#selectTagName(int)
	 */
	@Override
	public String selectTagName(int tag_id) {
		String selectOne = myBatis.selectOne("selectTagName", tag_id);
		return selectOne;
	}

	// 태그에 포함된 취미 조회(태그 한개)
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iHobbeeDao#selectHobby(int)
	 */
	@Override
	// 지윤이가 했다
	public List<Hobby> selectHobby(int tag_id) {
		List<Hobby> list = new ArrayList<Hobby>();
		list = myBatis.selectList("selectHobbybyTag", tag_id);
		return list;
	}

	// 태그 추가
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iHobbeeDao#insertTag(honeyhobbee.vo.Tag)
	 */
	@Override
	public void insertTag(Tag t) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;

		try {
			con = DBUtil.getConnection();
			String sql = "insert into tag values(?,?)";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, t.getTag_id());
			stmt.setString(2, t.getTag_name());
			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	// 태그 수정
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iHobbeeDao#updateTag(honeyhobbee.vo.Tag)
	 */
	@Override
	public void updateTag(Tag t) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = DBUtil.getConnection();
			String sql = "update tag set tag_name=? where tag_id=?";

			ps = con.prepareStatement(sql);
			ps.setString(1, t.getTag_name());
			ps.setInt(2, t.getTag_id());

			ps.executeUpdate();
		} finally {
			DBUtil.close(ps);
			DBUtil.close(con);
		}
	}

	// 태그 조회
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iHobbeeDao#selectAllTag()
	 */
	@Override
	public List<Tag> selectAllTag() {

		// String sql = "select * from tag order by tag_id";

		List<Tag> taglist = myBatis.selectList("selectAllTag");

		return taglist;
	}

	// 태그1, 2, 3 조회
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iHobbeeDao#selectTagList(int)
	 */
	@Override
	public List<Tag> selectTagList(int num) {

		// String sql =
		// "select * from tag where tag_id like #{num}||% order by tag_id";

		List<Tag> selectList = new ArrayList<Tag>();

		selectList = myBatis.selectList("selectTagList", num);

		return selectList;

	}

	// 직업 가져오기
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iHobbeeDao#selectAllJob()
	 */
	@Override
	public List<Job> selectAllJob() {
		// String sql = "select * from Job order by job_id";
		List<Job> selectList = new ArrayList<Job>();
		selectList = myBatis.selectList("selectAllJob");
		return selectList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iHobbeeDao#deleteTag(int)
	 */
	@Override
	public void deleteTag(int tag_id) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = DBUtil.getConnection();
			String q = "delete from tag where tag_id=?";
			ps = con.prepareStatement(q);
			ps.setInt(1, tag_id);
			ps.executeUpdate();
		} finally {
			DBUtil.close(ps);
			DBUtil.close(con);
		}

	}

	@Override
	public List<Tag> selectTagListByHobbyid(int hobby_id) {
		List<Tag> selectList = new ArrayList<Tag>();

		Tag tag1 = myBatis.selectOne("selectTag1ListByHobbyid", hobby_id);
		Tag tag2 = myBatis.selectOne("selectTag2ListByHobbyid", hobby_id);
		Tag tag3 = myBatis.selectOne("selectTag3ListByHobbyid", hobby_id);
		selectList.add(tag1);
		selectList.add(tag2);
		selectList.add(tag3);
		return selectList;
	}


	
}
