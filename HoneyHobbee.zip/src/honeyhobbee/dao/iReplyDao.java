package honeyhobbee.dao;

import honeyhobbee.vo.Reply;

import java.sql.SQLException;
import java.util.List;

public interface iReplyDao {

	// reply 등록
	public abstract void insertReply(Reply r) throws SQLException;

	//reply 수정
	public abstract void updateReply(Reply r) throws SQLException;

	//reply 삭제
	public abstract void deleteReply(Reply r) throws SQLException;

	//reply 조회
	public abstract List<Reply> selectAllReply(int post_id) throws SQLException;

}