package honeyhobbee.dao;

import honeyhobbee.vo.Member;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository("memberDAO")
public class MemberDao implements iMemberDao {

	
	@Autowired
	@Qualifier("sqlSession")
	private SqlSession myBatis;
	// 로그인
	/* (non-Javadoc)
	 * @see honeyhobbee.dao.iMemberDao#login(java.lang.String, java.lang.String)
	 */
	@Override
	public Member login(Member m){
		Member member = null;
		System.out.println(m);
		member =  myBatis.selectOne("login", m);
		System.out.println("login : " + member);
		
		return member;
	}

	// 회원가입
	/* (non-Javadoc)
	 * @see honeyhobbee.dao.iMemberDao#insertMember(honeyhobbee.vo.Member)
	 */
	@Override
	public void insertMember(Member m){
		System.out.println("dao"+m);
		myBatis.insert("insertMember", m);
		
	}

	// 회원정보 수정(이메일, 생일, 성별 빼고 변경가능)
	/* (non-Javadoc)
	 * @see honeyhobbee.dao.iMemberDao#updateMember(honeyhobbee.vo.Member)
	 */
	@Override
	public void updateMember(Member m){
		
		myBatis.update("updateMember", m);
	}

	// 회원 탈퇴
	/* (non-Javadoc)
	 * @see honeyhobbee.dao.iMemberDao#deleteMember(java.lang.String)
	 */
	@Override
	public void deleteMember(String email){

		myBatis.delete("deleteMember", email);
	}

	// 전체회원 조회
	/* (non-Javadoc)
	 * @see honeyhobbee.dao.iMemberDao#searchAllMember()
	 */
	@Override
	public List<Member> searchAllMember() {
		List<Member> list = new ArrayList<Member>();
		list = myBatis.selectList("searchAllMember");
		System.out.println(list);
		
		return list;
	}

	// email로 회원 검색
	/* (non-Javadoc)
	 * @see honeyhobbee.dao.iMemberDao#searchEmail(java.lang.String)
	 */
	@Override
	public Member searchEmail(String email){
		Member member = null;
		
		member = myBatis.selectOne("searchMember", email);
		System.out.println("searchEmail "+member);
		
		return member;
	}

	// 회원 사진 가져옴
	/* (non-Javadoc)
	 * @see honeyhobbee.dao.iMemberDao#searchMemberImage(java.lang.String)
	 */
	@Override
	public String searchMemberImage(String email){
		
		Member member = myBatis.selectOne("searchMember", email);
		String image = member.getImage();
		
		return image;
	}

	@Override
	public String findEmail(Member m) {
		System.out.println(m);
		String email = myBatis.selectOne("findEmail", m);
		System.out.println(email);
		return email;
	}

	@Override
	public String findPassword(Member m) {
		int tmpPassword = (int) (Math.random()*100000000);
		m.setPassword(String.valueOf(tmpPassword));
		myBatis.update("updateTmpPassword", m);
		return String.valueOf(tmpPassword);
	}



}
