package honeyhobbee.dao;

import honeyhobbee.vo.Post;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository("postDAO")
public class PostDao implements iPostDao {

	@Autowired
	@Qualifier("sqlSession")
	private SqlSession myBatis;

	@Override
	public void insertPost(Post p) {
		System.out.println("dao 에서 만난 p " + p);
		if(p.getMember_image()==null){
			p.setMember_image("null");
		}
		myBatis.insert("insertPost", p);
	}

	// post 수정
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iPostDao#updatePost(honeyhobbee.vo.Post)
	 */
	@Override
	public void updatePost(Post post) {
		System.out.println("dao 에서 만난 postUpdate" + post);
		myBatis.update("updatePost", post);
	}

	// post 삭제
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iPostDao#deletePost(int)
	 */
	@Override
	public void deletePost(int post_id) {
		myBatis.delete("deletePost", post_id);

	}

	// 전체 포스트 조회
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iPostDao#selectAllPost()
	 */
	@Override
	public List<Post> selectAllPost() {
		List<Post> list = new ArrayList<Post>();
		list = myBatis.selectList("getPostList");
		return list;
	}

	// 포스트 한 개 조회
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iPostDao#selectPost(int)
	 */
	@Override
	public Post selectPost(int post_id) throws SQLException {

		Post post = myBatis.selectOne("getPostById", post_id);

		return post;
	}

	// 한 사람이 쓴 포스트 전체 조회
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iPostDao#selectPostList(java.lang.String)
	 */
	@Override
	public List<Post> selectPostList(String email) {

		List<Post> list = new ArrayList();
		list = myBatis.selectList("getPostByEmail", email);

		return list;
	}

	// 취미와 관련된 포스트 가져옴
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iPostDao#selectPostListByHobby_id(int)
	 */
	@Override
	public List<Post> selectPostListByHobby_id(int hobby_id) {

		List<Post> list = new ArrayList();
		list = myBatis.selectList("getPostByHobby_id", hobby_id);
		/*
		 * p.setMember_image(new MemberDao().searchMemberImage(rs
		 * .getString(7)));
		 */

		return list;

	}

	// 취미와 관련된 태그네임가져옴
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iPostDao#selectTagNameList(int)
	 */
	/*
	 * @Override public List<String> selectTagNameList(int hobby_id) throws
	 * SQLException { Connection con = null; PreparedStatement ps = null;
	 * ResultSet rs = null; Post p = null; List<String> list = new
	 * ArrayList<String>(); try { con = DBUtil.getConnection(); for (int i = 1;
	 * i <= 3; i++) { String sql =
	 * "select tag_name from post p, hobby h, tag t " +
	 * "where p.hobby_id = h.hobby_id " + "and h.tag_id" + i + "= t.tag_id " +
	 * "and p.hobby_id = ?"; ps = con.prepareStatement(sql); ps.setInt(1,
	 * hobby_id); rs = ps.executeQuery(); if (rs.next()) { String tag_name =
	 * rs.getString(1); list.add(tag_name); } } } finally { DBUtil.close(rs);
	 * DBUtil.close(ps); DBUtil.close(con); } return list; }
	 */

	// 좋아요
	/*
	 * (non-Javadoc)
	 * 
	 * @see honeyhobbee.dao.iPostDao#likePost(int)
	 */
	@Override
	public void likePost(int post_id) {

		myBatis.update("likePost", post_id);

	}

	@Override
	public List<Post> selectTagsPosts(int tag_id) {
		List<Post> list = new ArrayList();
		list = myBatis.selectList("selectTagsPosts", tag_id);
		return list;
	}

}
