package honeyhobbee.service;

import honeyhobbee.vo.Hobby;
import honeyhobbee.vo.Job;
import honeyhobbee.vo.Tag;

import java.util.List;

public interface iHobbeeService {
	// 취미 추가
	public abstract void insertHobby(Hobby h);

	// 취미 수정
	public abstract void updateHobby(Hobby h);

	// 취미삭제
	public abstract void deletePost(Hobby h);

	// 취미 전체 조회
	public abstract List<Hobby> selectAllHobby();

	// 태그 이름 조회
	public abstract String selectTagName(int tag_id);

	// 태그에 포함된 취미 조회(태그 한개)
	public abstract List<Hobby> selectHobby(int tag_id);

	// 태그 추가
	public abstract void insertTag(Tag t);

	// 태그 수정
	public abstract void updateTag(Tag t);

	// 태그 조회
	public abstract List<Tag> selectAllTag();

	// 태그1, 2, 3 조회
	public abstract List<Tag> selectTagList(int num);

	// 직업 가져오기
	public abstract List<Job> selectAllJob();

	public abstract void deleteTag(int tag_id);
}
