package com.samsung.view.user;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.biz.user.impl.UserDAO;
import com.samsung.biz.user.vo.UserVO;

public class EmailCheckController implements Controller {
	UserDAO uDao;

	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();

		boolean isDupl = false;

		uDao = new UserDAO();

		HttpSession s = request.getSession();
		String id = request.getParameter("id");
		if (id != null) {

			UserVO userVO = uDao.searchEmail(id);

			mav.addObject("id", id);

			if (userVO != null) {
				isDupl = true;

				mav.addObject("isDupl", isDupl);
				mav.setViewName("duplicate.jsp");
				return mav;
			} else {
				mav.addObject("isDupl", isDupl);
				mav.setViewName("duplicate.jsp");
				return mav;
			}
		}

		return mav;
	}
}
