package com.samsung.biz.board.impl;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.samsung.biz.board.vo.BoardVO;
import com.samsung.biz.utils.JDBCUtil;
import com.sun.org.apache.regexp.internal.recompile;

public class BoardDAO {
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	
	public void addBoard(BoardVO vo, String today){
		Connection conn= JDBCUtil.getConnections();
		
		String sql = "";
		if(today.equals("")){
			sql = "insert into board(seq,title, nickname, content, regdate, userid, family,parent,depth,indent) "
					+ "values((select nvl(max(seq), 0) from board) +1 , ?, ?, ?, sysdate, 'guest', (select nvl(max(seq), 0) from board) +1, 0,0,0)";
		}else{
			sql = "insert into board(seq,title, nickname, content, regdate, userid, family,parent,depth,indent) "
					+ "values((select nvl(max(seq), 0) from board) +1 , ?, ?, ?, ?, 'guest', (select nvl(max(seq), 0) from board) +1, 0,0,0)";
		}
		
		try {
			stmt = conn.prepareStatement(sql);
			if(today.equals("")){
				stmt.setString(1, vo.getTitle());
				stmt.setString(2, vo.getNickname());
				stmt.setString(3, vo.getContent());
			}else{
				stmt.setString(1, vo.getTitle());
				stmt.setString(2, vo.getNickname());
				stmt.setString(3, vo.getContent());
				Date regDate = Date.valueOf(today);
				stmt.setDate(4, regDate);
			}
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt);
	}
	
	public void updateBoard(BoardVO vo){
		Connection conn= JDBCUtil.getConnections();
		String sql = "update board set title=?, content=?, cnt = cnt+1 where seq=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getTitle());
			stmt.setString(2, vo.getContent());
			stmt.setInt(3, vo.getSeq());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt);
	}
	
	public void deleteBoard(BoardVO vo){
		Connection conn= JDBCUtil.getConnections();
		String sql = "delete from board where seq=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getSeq());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt);	
	}
	// Resultset 값을 적절히 처리해서 넘겨야 한다
	public BoardVO getBoard(BoardVO vo){
		BoardVO b = null;
		Connection conn= JDBCUtil.getConnections();
		String sql = "select * from board where seq=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getSeq());
			rs = stmt.executeQuery();
			
			if(rs.next()){
				b = new BoardVO(rs.getInt("seq"), rs.getString("title"), rs.getString("nickname"), 
						rs.getString("content"), rs.getDate("regdate"), rs.getInt("cnt"), rs.getString("userid"),
						rs.getInt("indent"), rs.getInt("family"), rs.getInt("parent"), rs.getInt("depth"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt, rs);
		return b;
	}
	
	public ArrayList<BoardVO> getBoardList(BoardVO vo) {
		BoardVO b = null;
		ArrayList<BoardVO> list = new ArrayList<BoardVO>();
		
		Connection conn= JDBCUtil.getConnections();
		String sql = "";
		
		if(vo.getSearchCondition().equals("TITLE")){
			sql = "select * from board where title like '%' ||?|| '%' order by family desc, depth asc";
		}else{
			sql = "select * from board where content like '%' ||?|| '%' order by family desc, depth asc";
		}
		
		try {
			stmt = conn.prepareStatement(sql);
			//stmt.setString(1, '%'+vo.getSearchKeyword()+'%');
			stmt.setString(1, vo.getSearchKeyword());
			rs = stmt.executeQuery();
			
			while(rs.next()){
				b = new BoardVO(rs.getInt("seq"), rs.getString("title"), rs.getString("nickname"), 
						rs.getString("content"), rs.getDate("regdate"), rs.getInt("cnt"), rs.getString("userid"),
						rs.getInt("indent"), rs.getInt("family"), rs.getInt("parent"), rs.getInt("depth"));
				
				list.add(b);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt, rs);
		return list;
	}
}
