package com.samsung.view.board;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;
import com.samsung.biz.user.impl.UserDAO;
import com.samsung.biz.user.vo.UserVO;

public class AddReplyController implements Controller {
	private Boolean deleteBoard;

	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		String title = request.getParameter("title");
		String nickname = request.getParameter("nickname");
		String content = request.getParameter("content");
		String today = "";
		if(request.getParameter("regdate") != null){
			today = request.getParameter("regdate");
		}
		int parent = Integer.parseInt(request.getParameter("seq"));
		int family = Integer.parseInt(request.getParameter("family"));
		int depth = Integer.parseInt(request.getParameter("depth"));
		int indent = Integer.parseInt(request.getParameter("indent"));
		
		BoardVO vo = new BoardVO();
		vo.setTitle(title);
		vo.setNickname(nickname);
		vo.setContent(content);
		vo.setParent(parent);
		vo.setFamily(family);
		vo.setDepth(depth);
		vo.setIndent(indent);
		
		BoardDAO dao = new BoardDAO();
		dao.addReply(vo, today);
		
		mav.setViewName("getBoardList.do");
		

		return mav;
	}
}
