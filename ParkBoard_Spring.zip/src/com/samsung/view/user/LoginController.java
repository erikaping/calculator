package com.samsung.view.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.biz.user.impl.UserDAO;
import com.samsung.biz.user.vo.UserVO;

public class LoginController implements Controller {
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		
		String id = request.getParameter("id");
		String password = request.getParameter("password");

		UserVO vo = new UserVO();
		vo.setId(id);
		vo.setPassword(password);

		UserDAO dao = new UserDAO();
		UserVO user = dao.login(vo);
		
		ModelAndView mav = new ModelAndView();
		if (user != null) {
			mav.setViewName("getBoardList.do");
			HttpSession sess = request.getSession();
			sess.setAttribute("name", user.getName());
			sess.setAttribute("id", user.getId());
		} else {
	
			mav.addObject("notMatch", true);
			mav.setViewName("login.jsp");
		}
	
		return mav;
	}
}
