package com.samsung.view.user;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.biz.user.impl.UserDAO;
import com.samsung.biz.user.vo.UserVO;

public class JoinController implements Controller {
	UserDAO uDao;

	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();

		try {
			uDao = new UserDAO();
			HttpSession s = request.getSession();
			String id = request.getParameter("id");
			String password = request.getParameter("password");
			String name = request.getParameter("name");

			UserVO vo = new UserVO(id, password, name);

			System.out.println(vo);

			int userInsert = uDao.userInsert(vo);

			System.out.println(userInsert);

			if (userInsert == 1) {
				s.setAttribute("id", vo.getId());
				s.setAttribute("name", vo.getName());
				response.sendRedirect("getBoardList.do");
				mav.setViewName("getBoardList.do");
			} else {

				mav.setViewName("userInsert.jsp");
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		return mav;
	}
}
