package com.samsung.biz.board.impl;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.samsung.biz.board.vo.BoardVO;
import com.samsung.biz.utils.JDBCUtil;
import com.sun.org.apache.regexp.internal.recompile;

@Repository("boardDao")
public class BoardDAO {
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private PreparedStatement stmt2 = null;
	private ResultSet rs = null;
	
	public void addBoard(BoardVO vo, String today){
		Connection conn= JDBCUtil.getConnections();
		
		String sql = "";
		if(today.equals("")){
			sql = "insert into board(seq,title, nickname, content, regdate, userid, family,parent,depth,indent) "
					+ "values((select nvl(max(seq), 0) from board) +1 , ?, ?, ?, sysdate, 'guest', (select nvl(max(seq), 0) from board) +1, 0,0,0)";
		}else{
			sql = "insert into board(seq,title, nickname, content, regdate, userid, family,parent,depth,indent) "
					+ "values((select nvl(max(seq), 0) from board) +1 , ?, ?, ?, ?, 'guest', (select nvl(max(seq), 0) from board) +1, 0,0,0)";
		}
		
		try {
			stmt = conn.prepareStatement(sql);
			if(today.equals("")){
				stmt.setString(1, vo.getTitle());
				stmt.setString(2, vo.getNickname());
				stmt.setString(3, vo.getContent());
			}else{
				stmt.setString(1, vo.getTitle());
				stmt.setString(2, vo.getNickname());
				stmt.setString(3, vo.getContent());
				Date regDate = Date.valueOf(today);
				stmt.setDate(4, regDate);
			}
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt);
	}
	
	public void addReply(BoardVO vo, String today){
		Connection conn= JDBCUtil.getConnections();
			//depth 媛깆떊�슜 荑쇰━
			String sql = "update board set depth = depth + 1 where family=? and depth > ? ";
			//�떟蹂��벐湲곗슜 荑쇰━
			String sql2 = "";
			if(today.equals("")){
				sql2 = "insert into board(seq,title, nickname, content, regdate, userid, family, parent, depth, indent) "
						+ "values((select nvl(max(seq), 0) from board) +1 , ?, ?, ?, sysdate, 'guest', ?, ?, ?, ?)";
			}else{
				sql2 = "insert into board(seq,title, nickname, content, regdate, userid, family, parent, depth, indent) "
						+ "values((select nvl(max(seq), 0) from board) +1 , ?, ?, ?, ?, 'guest', ?, ?, ?, ?)";
			}
			
		try {
				stmt = conn.prepareStatement(sql);
				stmt.setInt(1, vo.getFamily());
				stmt.setInt(2, vo.getDepth());
				stmt.executeUpdate();
				
				stmt2 = conn.prepareStatement(sql2);
				if(today.equals("")){
					stmt2.setString(1, vo.getTitle());
					stmt2.setString(2, vo.getNickname());
					stmt2.setString(3, vo.getContent());
					
					stmt2.setInt(4, vo.getFamily());
					stmt2.setInt(5, vo.getParent());
					stmt2.setInt(6, vo.getDepth()+1);
					stmt2.setInt(7, vo.getIndent()+1);
				}else{
					stmt2.setString(1, vo.getTitle());
					stmt2.setString(2, vo.getNickname());
					stmt2.setString(3, vo.getContent());
					Date regDate = Date.valueOf(today);
					stmt2.setDate(4, regDate);
					stmt2.setInt(5, vo.getFamily());
					stmt2.setInt(6, vo.getParent());
					stmt2.setInt(7, vo.getDepth()+1);
					stmt2.setInt(8, vo.getIndent()+1);
				}
				stmt2.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt, stmt2);
	}
	
	public void updateBoard(BoardVO vo){
		Connection conn= JDBCUtil.getConnections();
		String sql = "update board set title=?, content=?, cnt = cnt+1 where seq=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getTitle());
			stmt.setString(2, vo.getContent());
			stmt.setInt(3, vo.getSeq());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt);
	}
	
	public Boolean deleteBoard(BoardVO vo){
		Connection conn= JDBCUtil.getConnections();
		String sql1 = "SELECT count(*) cnt FROM board WHERE parent = ?";
		String sql2 = "delete from board where seq=?";
		boolean check = false;
		try {
			stmt = conn.prepareStatement(sql1);
			stmt.setInt(1, vo.getSeq());
			rs = stmt.executeQuery();
			rs.next();
			int num = rs.getInt("cnt");
			
			if(num  == 0 ){
				check = true;
			}
			
			if(check == true){
					stmt2 = conn.prepareStatement(sql2);
					stmt2.setInt(1, vo.getSeq());
					stmt2.executeUpdate();
			} 
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		JDBCUtil.close(conn, stmt, stmt2, rs);	
		return check;
	}
	
	/*public void deleteBoard(BoardVO vo){
		Connection conn= JDBCUtil.getConnections();
		String sql = "delete from board where seq=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getSeq());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt);	
	}*/
	// Resultset 媛믪쓣 �쟻�젅�엳 泥섎━�빐�꽌 �꽆寃⑥빞 �븳�떎
	public BoardVO getBoard(BoardVO vo){
		BoardVO b = null;
		Connection conn= JDBCUtil.getConnections();
		String sql = "select * from board where seq=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getSeq());
			rs = stmt.executeQuery();
			
			if(rs.next()){
				b = new BoardVO(rs.getInt("seq"), rs.getString("title"), rs.getString("nickname"), 
						rs.getString("content"), rs.getDate("regdate"), rs.getInt("cnt"), rs.getString("userid"),
						rs.getInt("indent"), rs.getInt("family"), rs.getInt("parent"), rs.getInt("depth"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt, rs);
		return b;
	}
	public BoardVO replyBoard(BoardVO vo){
		final String LINE_SEPARATOR = System.getProperty("line.separator");
		BoardVO b = null;
		Connection conn= JDBCUtil.getConnections();
		String sql = "select * from board where seq=?";
		
		String content = null;
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getSeq());
			rs = stmt.executeQuery();
			
			if(rs.next()){
				content = rs.getString("content");
				content = content.replaceAll(LINE_SEPARATOR, LINE_SEPARATOR+">");
				content = LINE_SEPARATOR + LINE_SEPARATOR + ">" + content;
				
				b = new BoardVO(rs.getInt("seq"), rs.getString("title"), rs.getString("nickname"), 
						content, rs.getDate("regdate"), rs.getInt("cnt"), rs.getString("userid"),
						rs.getInt("family"), rs.getInt("parent"),  rs.getInt("depth") , rs.getInt("indent"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt, rs);
		return b;
	}
	
	public ArrayList<BoardVO> getBoardList(BoardVO vo, int page, int interval) {
		BoardVO b = null;
		ArrayList<BoardVO> list = new ArrayList<BoardVO>();
		
		Connection conn= JDBCUtil.getConnections();
		String sql = "";
		
		if(vo.getSearchCondition().equals("TITLE")){
			sql="SELECT * FROM (" +
			         "SELECT ROWNUM R, A.* FROM (" + 
			          "select * from board where title like '%' ||?|| '%' order by family desc, depth asc) A) " +
			         "WHERE R>= ? and R <= ?";
			
			
		}else{
			sql="SELECT * FROM (" +
			         "SELECT ROWNUM R, A.* FROM (" + 
			          "select * from board where content like '%' ||?|| '%' order by family desc, depth asc) A) " +
			         "WHERE R>= ? and R <= ?";
		}
		
		try {
			stmt = conn.prepareStatement(sql);
			int start = 1; // 한페이지에 보여줄 게시글 시작 번호
			int end = interval; // 한페이지에 보여줄 게시글 마직막 번호
			// 페이지에 따른 글번호 계산
			if (page > 1) {
				start = (page - 1) * interval + 1;
//				end = start + interval - 1;
				end = page * interval;
			}
			
			//stmt.setString(1, '%'+vo.getSearchKeyword()+'%');
			stmt.setString(1, vo.getSearchKeyword());
			stmt.setInt(2, start);
			stmt.setInt(3, end);
			
			rs = stmt.executeQuery();
			
			while(rs.next()){
				b = new BoardVO(rs.getInt("seq"), rs.getString("title"), rs.getString("nickname"), 
						rs.getString("content"), rs.getDate("regdate"), rs.getInt("cnt"), rs.getString("userid"),
						rs.getInt("family"), rs.getInt("parent"), rs.getInt("depth"),rs.getInt("indent"));
				
				list.add(b);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt, rs);
		return list;
	}
	
	public int getTotalRecord() {
		int totalRecord = 0;
		Connection conn= JDBCUtil.getConnections();		
		String sql = "SELECT count(*) cnt FROM board";
		try {
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			
			if(rs.next()){
				totalRecord = rs.getInt("cnt");
			}
		} catch (SQLException e) {
		} finally {
			JDBCUtil.close(conn, stmt, rs);
		}
		
		return totalRecord;
	}
}
