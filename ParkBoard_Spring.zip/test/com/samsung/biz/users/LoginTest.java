package com.samsung.biz.users;

import com.samsung.biz.user.impl.UserDAO;
import com.samsung.biz.user.vo.UserVO;


public class LoginTest {
public static void main(String[] args) {
	UserVO vo = new UserVO();
	vo.setId("abc");
	vo.setPassword("abc123");
	
	UserDAO dao = new UserDAO();
	UserVO u = dao.login(vo);
	System.out.println(u);
}
}
