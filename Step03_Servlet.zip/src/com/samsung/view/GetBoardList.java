package com.samsung.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.utils.JDBCUtils;

/*@WebServlet(urlPatterns = { "/getBoardList", "/getBoardList" }, initParams = {
 @WebInitParam(name = "name", value = "홍길동"),
 @WebInitParam(name = "age", value = "20") })*/
public class GetBoardList extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		// 응답 페이지의 파일 형식과 언어 타입을 설정해야 한글이 안깨짐
		response.setContentType("text/html; charset=UTF-8");

		PrintWriter out = response.getWriter();

		// out.write("<h1>옥수수님 보이세요?</h1>");
		// out.write("<h1>보이시면 재채기 한번 </h1>");

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			// 1단계 => 사용할 클래스를 올리자

			conn = JDBCUtils.getConnections();
			// 3단계 => Query 준비
			// PreparedStatement 객체는 쿼리 실행 및 실행 전에 해야할 일에 대한 메소드를 가지고 있다.
			String sql = "select * from board order by seq desc";
			stmt = conn.prepareStatement(sql);
			// 4단계 => 쿼리에 들어갈 변수들을 세팅하는 작업
			// stmt.setInt(1, 100);
			// 5단계 =>
			rs = stmt.executeQuery();
			out.println("<h1>게시물목록</h1>");
			while (rs.next()) {
				int seq = rs.getInt("seq");
				String nickname = rs.getString("nickname");
				String content = rs.getString("content");
				Date regdate = rs.getDate("regdate");
				int cnt = rs.getInt("cnt");
				String userid = rs.getString("userid");

				out.println(seq + " - " + nickname + " - " + content + " - "
						+ regdate + " - " + cnt + " - " + userid);
				out.println("<br>");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt, rs);
		}

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

}
