package com.samsung.biz.inher;

import java.util.ArrayList;

public class JumsuMain {
	public static void main(String[] args) {

		JumsuTwo hong = new JumsuTwo("홍길동", 100, 95);
		hong.display();

		JumsuThree im = new JumsuThree("임꺽정", 100, 95, 45);
		im.display();

		JumsuFour jimea = new JumsuFour("일지매", 75, 95, 45, 95);
		jimea.display();

		// 내가 만든 클래스도 변수의 타입
		// 상속관계에서는 부모는 자식보다 큰 타입이다.
		// 따라서 다음과 같은 정의가 가능하다.
		// JumsuTwo > JumsuThree
		// JumsuTwo > JumsuFour

		ArrayList<JumsuTwo> jumsu = new ArrayList<JumsuTwo>();
		jumsu.add(hong);
		jumsu.add(im);
		jumsu.add(jimea);

		JumsuTwo test= new JumsuThree("임꺽정", 100, 95, 45);
		test.onTwo();
		
		int top = 0;
		JumsuTwo topPerson = null;
		for (JumsuTwo jT : jumsu) {
			jT.display();
			if (jT.vo.getAvg() > top) {
				top = jT.vo.getAvg();
				topPerson = jT;
			}
		}
		
		
		/*
		 * for (int i = 0; i < jumsu.size(); i++) { JumsuTwo jT = jumsu.get(i);
		 * jT.display(); if (jT.vo.getAvg() > top) { top = jT.vo.getAvg();
		 * topPerson = jT; } }
		 */

		System.out.println("최고점수 : " + top);
		System.out.println("그 주인공은? " + topPerson.vo.getName());

		
	}
}
