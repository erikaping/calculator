package com.samsung.biz.impl;

public class Polymorphism {
	public static void main(String[] args) {

		// 사용할 객체는 Factory로 부터 주입(DependencyInjection)받아 사용한다.
		JumsuFactory factory = new JumsuFactory();
		Jumsu jumsu = (Jumsu) factory.getBean();
		jumsu.display();

	}
}
