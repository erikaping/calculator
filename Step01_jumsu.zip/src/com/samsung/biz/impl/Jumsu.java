package com.samsung.biz.impl;

//껍데기 
public interface Jumsu {
	public void onTotal();
	public void onAvg();
	public void display();
}
