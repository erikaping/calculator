package com.samsung.biz.impl;

public class Main {
	public static void main(String[] args) {
		Jumsu hong = new Two("홍길동", 90, 55);
		Jumsu im = new Three("임꺽정", 65, 46, 99);
		Jumsu jimea = new Four("일지매", 75, 95, 45, 95);
		
		//1등 구하는 것은 전과 동일
		
		
	}
}
