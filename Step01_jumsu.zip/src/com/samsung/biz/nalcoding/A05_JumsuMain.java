package com.samsung.biz.nalcoding;

public class A05_JumsuMain {
	public static void main(String[] args) {
/*
		A05_Jumsu hong = new A05_Jumsu();

		hong.setName("홍길동");
		hong.setKor(90);
		hong.setEng(80);
		hong.setMath(75);

		A05_Jumsu im = new A05_Jumsu("임꺽정", 100, 95, 85);
		A05_Jumsu jimea = new A05_Jumsu("일지매", 100, 95, 100);

		System.out.println(hong);
		System.out.println(im);
		System.out.println(jimea);

		hong.display();
		im.display();
		jimea.display();

		A05_Jumsu nol = new A05_Jumsu();
		nol.setName("놀부");
		nol.setKor(90);
		nol.setEng(35);
		nol.setMath(74);*/

		A05_JumsuDAO hong = new A05_JumsuDAO("홍길동",95,85,100);
		hong.display();
	}
}
