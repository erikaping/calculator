package com.samsung.biz.nalcoding;

public class Managers {
	int empId;
	String empName;
	String empEmail;
	String empdept;
	String empPhone;
	String empHiredate;
	int empSalary;
	
	public Managers(int empId, String empName, String empEmail,
			String empdept, String empPhone, String empHiredate, int empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empEmail = empEmail;
		this.empdept = empdept;
		this.empPhone = empPhone;
		this.empHiredate = empHiredate;
		this.empSalary = empSalary;
	}

}
