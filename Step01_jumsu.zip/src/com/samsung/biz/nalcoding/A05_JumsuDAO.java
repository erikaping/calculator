package com.samsung.biz.nalcoding;

import javax.jws.Oneway;

public class A05_JumsuDAO {

	private A05_Jumsu vo = null;

	public A05_JumsuDAO(String name, int kor, int eng, int math) {
		vo = new A05_Jumsu();
		vo.setName(name);
		vo.setKor(kor);
		vo.setEng(eng);
		vo.setMath(math);
	}

	public int onTotal() {

		return (vo.getKor() + vo.getMath() + vo.getMath());
		

	}

	public int onAvg() {
		return (vo.getTotal() / 3);
	}

	public void display() {
		System.out.println(vo.getName() + "님의 총점은 " + onTotal() + "점이고 평균은 "
				+ onAvg() + "입니다.");
	}

}
