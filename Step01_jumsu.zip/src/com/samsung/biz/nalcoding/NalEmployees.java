package com.samsung.biz.nalcoding;

public class NalEmployees {
	public static void main(String[] args) {

		int emp1Id = 37720;
		String emp1Name = "박지윤";
		String emp1Email = "j_erika.park@samsung.com";
		String emp1dept = "의료원CI그룹";
		String emp1Phone = "01099799098";
		String emp1Hiredate = "2015/03/03";
		int emp1Salary = 4000;

		int emp2Id = 38820;
		String emp2Name = "김홍열";
		String emp2Email = "honghong@samsung.com";
		String emp2dept = "의료원CI그룹";
		String emp2Phone = "01077778080";
		String emp2Hiredate = "2015/02/27";
		int emp2Salary = 4000;
	}
}
