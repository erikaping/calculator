package com.samsung.biz.nalcoding;

// 내가 만든 클래스도 변수명(변수타입)이다
// 이렇게 만들면 다양한 타입의 변수를 하나의 이름으로 관리할 수 있다
public class A05_Jumsu {
	private String name;
	private int kor;
	private int eng;
	private int math;
	private int total;
	private int avg;

	public void onTotal() {
		total = this.kor + eng + math;
	}

	public void onAvg() {
		avg = this.total / 3;
	}

	public void display() {
		System.out
				.println(name + "님의 총점은 " + total + "점이고 평균은 " + avg + "입니다.");
	}

	// ///////////////////////////////////////////////////////////////////////

	// 기본 생성자
	// 생성자 오버로딩
	public A05_Jumsu() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getKor() {
		return kor;
	}

	public void setKor(int kor) {
		this.kor = kor;
	}

	public int getEng() {
		return eng;
	}

	public void setEng(int eng) {
		this.eng = eng;
	}

	public int getMath() {
		return math;
	}

	public void setMath(int math) {
		this.math = math;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getAvg() {
		return avg;
	}

	public void setAvg(int avg) {
		this.avg = avg;
	}

	// 생성자 메소드명은 이름대신 this()를 사용한다.
	public A05_Jumsu(String name, int kor) {
		this.name = name;
		this.kor = kor;
	}

	// JVM은 생성자 메소드가 없으면 기본 생성자 메소드를 자동으로 만들어 준다.
	// 생성자 메소드를 프로그래머가 하나라도 만들면 기본 생성자 메소드를 JVM이 안만들어준다.
	// 따라서 필요한 생성자는 꼭 프로그래머가 만들어야한다.
	// 생성자 오버로딩

	public A05_Jumsu(String name, int kor, int eng, int math) {
		this(name, kor);
		this.eng = eng;
		this.math = math;
		this.total = kor + eng + math;
		this.avg = total / 3;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("A05_Jumsu [name=");
		builder.append(name);
		builder.append(", kor=");
		builder.append(kor);
		builder.append(", eng=");
		builder.append(eng);
		builder.append(", math=");
		builder.append(math);
		builder.append(", total=");
		builder.append(total);
		builder.append(", avg=");
		builder.append(avg);
		builder.append("]");
		return builder.toString();
	}

}
