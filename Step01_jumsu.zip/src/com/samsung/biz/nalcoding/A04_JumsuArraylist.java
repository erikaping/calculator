package com.samsung.biz.nalcoding;

import java.util.ArrayList;

public class A04_JumsuArraylist {
	public static void main(String[] args) {

		ArrayList<String> name = new ArrayList<String>();
		name.add("홍길동");
		name.add("일지매");
		name.add("임꺽정");

		ArrayList<Integer> hong = new ArrayList<Integer>();
		hong.add(90);
		hong.add(80);
		hong.add(70);
		ArrayList<Integer> im = new ArrayList<Integer>();
		im.add(100);
		im.add(95);
		im.add(85);
		ArrayList<Integer> jimea = new ArrayList<Integer>();
		jimea.add(100);
		jimea.add(95);
		jimea.add(100);

		ArrayList<ArrayList<Integer>> jumsu = new ArrayList<ArrayList<Integer>>();
		jumsu.add(hong);
		jumsu.add(im);
		jumsu.add(jimea);

		for (int i = 0; i < jumsu.size(); i++) {
			ArrayList<Integer> su = jumsu.get(i);
			int total = 0;
			for (int j = 0; j < su.size(); j++) {
				total = su.get(0) + su.get(1) + su.get(2);
			}
			su.add(total);
			su.add(su.get(3) / 3);
			System.out.println(name.get(i) + "님의 총점은 " + su.get(3) + "이고 평균은 "
					+ su.get(4) + "입니다");
		}

	}
}
