package com.samsung.tv;

public class LGTV implements TV {

	@Override
	public void powerOn() {
		System.out.println("엘쥐TV => 전원 켜기");

	}

	@Override
	public void powerOff() {
		System.out.println("엘쥐TV => 전원 끄기");

	}

	@Override
	public void volumUp() {
		System.out.println("엘쥐TV => 소리 올리기");

	}

	public void volumDown() {
		System.out.println("엘쥐TV => 소리 내리기");

	}
}
