package com.samsung.tv;

public class TVUser {
	public static void main(String[] args) {

		TVFactory factory = new TVFactory();
		TV tv = factory.getBean("samsung");

		tv.powerOn();
		tv.volumUp();
		tv.volumDown();
		tv.powerOff();

	}
}
