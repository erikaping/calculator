drop table users;
drop table board;

create table users(
	id 			varchar2(28) 	primary key,
	password 	varchar2(20)		not null,
	name 		varchar2(30)	not null,
	grade 		number(10)		default 1
)

create table board(
	seq			number(5) 		primary key,
	title		varchar2(200)	not null,
	nickname	varchar2(30)	not null,
	content		varchar2(2000)	not null,
	regdate		date 			default sysdate,
	cnt			number(5)		default 0,
	userid		varchar2(8),
	family 		number(5),
	parent 		number(5),
	depth 		number(5),
	indent 		number(5),
	constraint board_userid_fk foreign key(userid) references users(id)
)

insert into users values('gurum', 'gurum123', '채규태', 2);
insert into users values('abc', 'abc123', '홍길동', 2);
insert into users values('guest', 'guest123', '임꺽정', 2);
insert into users values('psw', '123', '된다된다', 3);
insert into users values('erika', '123', 'erika', 3);

insert into board(seq, title, nickname, content, regdate, userid) 
values(1, '첫 번째 글', '된다된다', '첫 번째 등록글입니다.', '2015-05-10', 'psw');
insert into board(seq, title, nickname, content, regdate, userid) 
values(2, '두 번째 글', '된다된다', '두 번째 등록글입니다.', '2015-05-10', 'psw');
insert into board(seq, title, nickname, content, regdate, userid) 
values(3, '세 번째 글', '된다된다', '세 번째 등록글입니다.', '2015-05-10', 'psw');
insert into board(seq, title, nickname, content, regdate, userid) 
values(4, '55기 하계수련대회', '된다된다', '삼성SDS 신입사원 다 모여라', '2015-05-11', 'psw');
insert into board(seq, title, nickname, content, regdate, userid) 
values(5, '알고리즘 시험 안내', 'erika', '정올 홈페이지를 참고하세요.', '2015-05-16', 'erika');
insert into board(seq, title, nickname, content, regdate, userid) 
values(6, '신입사원 전력화', 'erika', '또 하나의 혁명', '2015-05-14', 'erika');

select * from users;
select * from board;

