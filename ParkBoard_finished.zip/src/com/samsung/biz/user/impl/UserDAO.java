package com.samsung.biz.user.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.samsung.biz.user.vo.UserVO;
import com.samsung.biz.utils.JDBCUtil;

public class UserDAO {
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;

	public UserVO login(UserVO vo) {
		conn = JDBCUtil.getConnections();
		UserVO user = null;
		String sql = "select * from users where id=? and password=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getId());
			stmt.setString(2, vo.getPassword());
			rs = stmt.executeQuery();

			if (rs.next()) {
				user = new UserVO();

				user.setId(rs.getString("id"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setGrade(rs.getInt("grade"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt, rs);
		return user;
	}

	public int userInsert(UserVO vo) {
		conn = JDBCUtil.getConnections();
		int result = 0;
		try {
			String sql = "insert into users(id,password, name, grade) "
					+ "values(?, ?, ?, 1)";

			PreparedStatement stmt = conn.prepareStatement(sql);

			stmt.setString(1, vo.getId());
			stmt.setString(2, vo.getPassword());
			stmt.setString(3, vo.getName());

			result = stmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, stmt);
		}

		return result;
	}

	public int userDelete(String id) {
		conn = JDBCUtil.getConnections();
		int result = 0;
		try {
			String sql = "delete from users where id = ? ";

			PreparedStatement stmt = conn.prepareStatement(sql);

			stmt.setString(1, id);

			result = stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			JDBCUtil.close(conn, stmt);
		}

		return result;
	}

	public int userUpdate(UserVO vo) {
		conn = JDBCUtil.getConnections();
		int result = 0;
		try {
			String sql = "update users set password = ? , name = ? where id = ?";

			PreparedStatement stmt = conn.prepareStatement(sql);

			stmt.setString(1, vo.getPassword());
			stmt.setString(2, vo.getName());
			stmt.setString(3, vo.getId());
			result = stmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			JDBCUtil.close(conn, stmt);
		}

		return result;
	}

	public UserVO searchEmail(String id) {
		conn = JDBCUtil.getConnections();
		UserVO user = null;

		try {
			String sql = "select * from users where id=? ";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, id);

			rs = stmt.executeQuery();

			if (rs.next()) {
				id = rs.getString("id");
				String password = rs.getString("password");
				String name = rs.getString("name");
				int grade = rs.getInt("grade");
				user = new UserVO(id, password, name, grade);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, stmt, rs);
		}
		return user;
	}

	public ArrayList<UserVO> usersList() {
		conn = JDBCUtil.getConnections();
		UserVO user = null;
		ArrayList<UserVO> uList = new ArrayList<>();

		try {
			String sql = "select * from users order by grade desc";
			stmt = conn.prepareStatement(sql);

			rs = stmt.executeQuery();

			while (rs.next()) {
				String id = rs.getString("id");
				String password = rs.getString("password");
				String name = rs.getString("name");
				int grade = rs.getInt("grade");
				user = new UserVO(id, password, name, grade);

				user = new UserVO(id, password, name, grade);
				uList.add(user);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, stmt, rs);
		}
		return uList;
	}

}
