package com.samsung.view.board;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class AddReply extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String title = request.getParameter("title");
		String nickname = request.getParameter("nickname");
		String content = request.getParameter("content");
		String today = "";
		if(request.getParameter("regdate") != null){
			today = request.getParameter("regdate");
		}
		int parent = Integer.parseInt(request.getParameter("seq"));
		int family = Integer.parseInt(request.getParameter("family"));
		int depth = Integer.parseInt(request.getParameter("depth"));
		int indent = Integer.parseInt(request.getParameter("indent"));
		
		BoardVO vo = new BoardVO();
		vo.setTitle(title);
		vo.setNickname(nickname);
		vo.setContent(content);
		vo.setParent(parent);
		vo.setFamily(family);
		vo.setDepth(depth);
		vo.setIndent(indent);
		
		BoardDAO dao = new BoardDAO();
		dao.addReply(vo, today);
		response.sendRedirect("getBoardList");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
