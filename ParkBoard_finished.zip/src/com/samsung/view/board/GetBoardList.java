package com.samsung.view.board;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;
import com.samsung.common.AdvancedPageUtility;

public class GetBoardList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BoardDAO dao = new BoardDAO();
		// 濡쒓렇�씤 �븞�뻽�쑝硫� 濡쒓렇�씤�븯怨� �뱾�뼱�삤�꽭�뿬...
		HttpSession sess = request.getSession();
		String id = (String) sess.getAttribute("id");
		if(id == null){
			response.sendRedirect("login.jsp");
			return;
		}
		
		// 留ㅺ컻蹂��닔媛믪씠 �씤 �꽆�뼱�솕�쓣 �븣瑜� ��鍮꾪빐�꽌... 
		String searchCondition = "";
		if(request.getParameter("searchCondition") ==null){
			searchCondition = "TITLE";
		}else{
			searchCondition = request.getParameter("searchCondition");
		}
		
		String searchKeyword = "";
		if(request.getParameter("searchKeyword") !=null){
			searchKeyword = request.getParameter("searchKeyword");
		}else{
			searchKeyword = "";
		}
		
		// 寃��깋�쓣 �븯吏� �븡�븯�떎硫�
		// searchCondition = "TITLE";
		// searchKeyword = "";
		BoardVO vo = new BoardVO();
		vo.setSearchCondition(searchCondition);
		vo.setSearchKeyword(searchKeyword);
		
		/// 페이징 작업 시작
		String cpage = request.getParameter("pageNo");
		ArrayList<BoardVO> list = null;
		int page = 1;
		
		if(cpage != null ){
			page = Integer.parseInt(cpage);
		}
		try {
			
			int interval = 10;  //한 페이지에 보여줄 상품 개수
			list =dao.getBoardList(vo, page, interval);
			int total = dao.getTotalRecord();
			total = total ==0 ? 1:total;
			
//			PageUtility  bar = new PageUtility(interval, total,page);
			AdvancedPageUtility  bar = new AdvancedPageUtility(interval, total,page,"images/");
			request.setAttribute("pageLink", bar.getPageBar());
			request.setAttribute("list", list);
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		// getBoardList method�뿉 媛믪쓣 �꽆湲대떎.
		// �씠 �븣 searchKeyword媛� 鍮� 臾몄옄�뿴�씠硫� �쟾泥대�� 異쒕젰
		
		RequestDispatcher dis = request.getRequestDispatcher("getBoardList.jsp");
		dis.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		doGet(request, response);
	}
}
