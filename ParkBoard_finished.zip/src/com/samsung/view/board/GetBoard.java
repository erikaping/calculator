package com.samsung.view.board;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;
/**
 * Servlet implementation class GetBoard
 */
public class GetBoard extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int seq = Integer.parseInt(request.getParameter("seq"));
		// 디비연결부터 결과값 받아오기
		BoardVO vo = new BoardVO();
		vo.setSeq(seq);
		
		BoardDAO dao = new BoardDAO();
		BoardVO board = dao.getBoard(vo);
		request.setAttribute("board", board);
		// 어느 페이지로 이동 할 것인지를 지정.
		RequestDispatcher dis = request.getRequestDispatcher("getBoard.jsp");
		// forword 로 이동하면서 현재 사용중인
		// request 와 response 객체를 전달한다
		dis.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		doGet(request, response);
	}

}
