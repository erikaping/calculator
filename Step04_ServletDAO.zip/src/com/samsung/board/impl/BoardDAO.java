package com.samsung.board.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.samsung.board.vo.Board;
import com.samsung.utils.JDBCUtils;

public class BoardDAO {
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;

	public ArrayList<Board> getBoardList() {

		ArrayList<Board> bList = new ArrayList<Board>();
		try {

			conn = JDBCUtils.getConnections();
			String sql = "select * from board order by seq desc";
			stmt = conn.prepareStatement(sql);

			rs = stmt.executeQuery();

			while (rs.next()) {
				int seq = rs.getInt("seq");
				String title = rs.getString("title");
				String nickname = rs.getString("nickname");
				String content = rs.getString("content");
				Date regdate = rs.getDate("regdate");
				int cnt = rs.getInt("cnt");
				String userid = rs.getString("userid");
				Board b = new Board(seq, title, nickname, content, regdate,
						cnt, userid);
				bList.add(b);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt, rs);
		}
		return bList;
	}

	public void updateBoard(Board vo) {

		try {
			conn = JDBCUtils.getConnections();

			String sql = "update board set title = ?, content = ?  where seq = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getTitle());
			stmt.setString(2, vo.getContent());
			stmt.setInt(3, vo.getSeq());

			int cnt = stmt.executeUpdate();
			System.out.println(cnt + "개가 정상 수정되었습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt);
		}
	}

	public void deleteBoard(Board vo) {

		try {
			// 1단계 => 사용할 클래스를 올리자
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2단계 => DB연결
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			conn = DriverManager.getConnection(url, "hr", "hr");
			// 3단계 => Query 준비
			// PreparedStatement 객체는 쿼리 실행 및 실행 전에 해야할 일에 대한 메소드를 가지고 있다.
			String sql = "delete from board where seq = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getSeq());

			// 리턴타입 : 몇 개의 쿼리가 실행됐는지의 카운트 수
			int cnt = stmt.executeUpdate();
			System.out.println(cnt + "개가 정상 삭제되었습니다.");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			JDBCUtils.close(conn, stmt);

		}
	}

	public void addBoard(Board b) {

		try {
			conn = JDBCUtils.getConnections();
			// 3단계 => Query 준비
			// PreparedStatement 객체는 쿼리 실행 및 실행 전에 해야할 일에 대한 메소드를 가지고 있다.
			String sql = "insert into board(seq,title, nickname, content, regdate, userid) "
					+ "values((select nvl(max(seq), 0) from board) +1 , ?, ?, ?, sysdate, 'guest')";
			stmt = conn.prepareStatement(sql);
			// 4단계 => 쿼리에 들어갈 변수들을 세팅하는 작업
			// ?에 대한 세팅작업
			stmt.setString(1, b.getTitle());
			stmt.setString(2, b.getNickname());
			stmt.setString(3, b.getContent());

			// 리턴타입 : 몇 개의 쿼리가 실행됐는지의 카운트 수
			stmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt);
		}
	}

	public Board getBoard(Board vo) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Board b = null;
		try {
			// 1단계 => 사용할 클래스를 올리자
			conn = JDBCUtils.getConnections();
			// 3단계 => Query 준비
			// PreparedStatement 객체는 쿼리 실행 및 실행 전에 해야할 일에 대한 메소드를 가지고 있다.
			String sql = "select * from board where seq = ?";
			stmt = conn.prepareStatement(sql);
			// 4단계 => 쿼리에 들어갈 변수들을 세팅하는 작업
			// stmt.setInt(1, 100);
			// 5단계 =>
			stmt.setInt(1, vo.getSeq());
			rs = stmt.executeQuery();

			if (rs.next()) {
				int seq = rs.getInt("seq");
				String title = rs.getString("title");
				String nickname = rs.getString("nickname");
				String content = rs.getString("content");
				Date regdate = rs.getDate("regdate");
				int cnt = rs.getInt("cnt");
				String userid = rs.getString("userid");

				b = new Board(seq, title, nickname, content, regdate, cnt,
						userid);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt, rs);
		}
		return b;
	}

}
