package com.samsung.board.vo;

import java.sql.Date;

public class Board {
	private int seq;
	private String title;
	private String nickname;
	private String content;
	private Date regdate;
	private int cnt;
	private String userid;

	public Board() {
		super();
	}

	public Board(int seq, String nickname, String content, Date regdate,
			int cnt, String userid) {
		super();
		this.seq = seq;
		this.nickname = nickname;
		this.content = content;
		this.regdate = regdate;
		this.cnt = cnt;
		this.userid = userid;
	}

	public Board(int seq, String title, String nickname, String content,
			Date regdate, int cnt, String userid) {
		super();
		this.seq = seq;
		this.title = title;
		this.nickname = nickname;
		this.content = content;
		this.regdate = regdate;
		this.cnt = cnt;
		this.userid = userid;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getRegdate() {
		return regdate;
	}

	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	public int getCnt() {
		return cnt;
	}

	public void setCnt(int cnt) {
		this.cnt = cnt;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Board [seq=");
		builder.append(seq);
		builder.append(", title=");
		builder.append(title);
		builder.append(", nickname=");
		builder.append(nickname);
		builder.append(", content=");
		builder.append(content);
		builder.append(", regdate=");
		builder.append(regdate);
		builder.append(", cnt=");
		builder.append(cnt);
		builder.append(", userid=");
		builder.append(userid);
		builder.append("]");
		return builder.toString();
	}

}
