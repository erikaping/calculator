package com.samsung.view;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.board.impl.BoardDAO;
import com.samsung.board.vo.Board;

public class AddBoard extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		// 응답 페이지의 파일 형식과 언어 타입을 설정해야 한글이 안깨짐
		response.setContentType("text/html; charset=UTF-8");

		Board vo = new Board();
		vo.setTitle("new Title");
		vo.setNickname("new Nickname");
		vo.setContent("new Content");

		BoardDAO bDao = new BoardDAO();
		bDao.addBoard(vo);
		response.sendRedirect("getBoardList");

	}

}
