package com.samsung.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.board.impl.BoardDAO;
import com.samsung.board.vo.Board;

public class GetBoard extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		// 응답 페이지의 파일 형식과 언어 타입을 설정해야 한글이 안깨짐
		response.setContentType("text/html; charset=UTF-8");

		PrintWriter out = response.getWriter();

		BoardDAO bDao = new BoardDAO();

		Board vo = new Board();
		vo.setSeq(3);
		Board board = bDao.getBoard(vo);
		out.println(board.toString());

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

}
