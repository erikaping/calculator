package com.samsung.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.board.impl.BoardDAO;
import com.samsung.board.vo.Board;

public class UpdateBoard extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");

		response.setContentType("text/html; charset=UTF-8");



		Board vo = new Board();
		vo.setTitle("니 운명을 믿지 마라");
		vo.setContent("니 운명을 믿지 말라고");
		vo.setSeq(2);

		BoardDAO bDao = new BoardDAO();
		bDao.updateBoard(vo);

		response.sendRedirect("getBoardList");
	}

}
