package com.samsung.biz.user;

import java.util.ArrayList;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class UpdateBoardTest {
	public static void main(String[] args) {
		BoardDAO dao = new BoardDAO();
		BoardVO vo = new BoardVO();
		vo.setSeq(20);
		vo.setTitle("홍쥬니와쥬니");
		vo.setContent("홍쥬니와 짝이된 지유니의 프로젝트는 꿀프로줵트");

		dao.updateBoard(vo);

	}
}
