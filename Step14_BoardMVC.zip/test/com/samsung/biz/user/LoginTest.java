package com.samsung.biz.user;

import com.samsung.biz.user.impl.UserDAO;
import com.samsung.biz.user.vo.UserVO;

public class LoginTest {
	public static void main(String[] args) {
		UserDAO dao = new UserDAO();

		String id = "guest";
		String password = "guest123";

		UserVO vo = new UserVO();
		vo.setId(id);
		vo.setPassword(password);
		System.out.println("VO : " + vo);
		UserVO user = dao.login(vo);

		if (user != null) {
			System.out.println(user.toString());
		} else {
			System.out.println(user);
		}

	}
}
