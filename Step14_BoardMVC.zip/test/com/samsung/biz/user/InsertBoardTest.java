package com.samsung.biz.user;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class InsertBoardTest {
	public static void main(String[] args) {
		BoardDAO dao = new BoardDAO();
		BoardVO vo = new BoardVO();
		vo.setTitle("홍쥬니와 짝이된 지유니");
		vo.setNickname("홍홍홍");
		vo.setContent("홍쥬니와 짝이된 지유니 우리의 프로젝트는 어떻게 될까?");
		vo.setUserid("guest");
		dao.insertBoard(vo);

		
	}
}
