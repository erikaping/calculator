package com.samsung.biz.user;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class DeleteBoardTest {
	public static void main(String[] args) {
		BoardDAO dao = new BoardDAO();
		BoardVO vo = new BoardVO();

		for (int i = 13; i <= 19; i++) {
			vo.setSeq(i);
			dao.deleteBoard(vo);
		}
	}
}
