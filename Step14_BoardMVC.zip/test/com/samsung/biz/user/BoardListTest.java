package com.samsung.biz.user;

import java.util.ArrayList;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class BoardListTest {
	public static void main(String[] args) {
		BoardDAO dao = new BoardDAO();
	//	ArrayList<BoardVO> boardList = dao.getBoardList();

	/*	for (BoardVO boardVO : boardList) {
			System.out.println(boardVO);
			
		}*/
		
	}
}
