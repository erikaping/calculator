package com.samsung.biz.user.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.samsung.biz.common.JDBCUtils;
import com.samsung.biz.user.vo.UserVO;

public class UserDAO {
	private ResultSet rs = null;
	private PreparedStatement stmt = null;
	private Connection conn = null;

	public UserVO login(UserVO vo) {

		UserVO user = null;

		try {
			conn = JDBCUtils.getConnection();
			String sql = "select * from users where id = ? and password=?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getId());
			stmt.setString(2, vo.getPassword());

			rs = stmt.executeQuery();

			if (rs.next()) {
				String id = rs.getString("id");
				String password = rs.getString("password");
				String name = rs.getString("name");
				String role = rs.getString("role");
				user = new UserVO(id, password, name, role);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt, rs);
		}
		return user;
	}

	public void logout() {

	}

}
