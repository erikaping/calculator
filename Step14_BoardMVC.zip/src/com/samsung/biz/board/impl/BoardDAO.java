package com.samsung.biz.board.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.samsung.biz.board.vo.BoardVO;
import com.samsung.biz.common.JDBCUtils;

public class BoardDAO {

	private ResultSet rs = null;
	private PreparedStatement stmt = null;
	private Connection conn = null;

	public ArrayList<BoardVO> getBoardList(BoardVO vo) {
		ArrayList<BoardVO> list = new ArrayList<>();
		String sql = "";
		try {
			conn = JDBCUtils.getConnection();

			if (vo.getSearchCondition().equals("TITLE")) {
				sql = "select * from board where title like '%'||?||'%' order by seq desc";
			} else if (vo.getSearchCondition().equals("CONTENT")) {
				sql = "select * from board where content like '%'||?||'%' order by seq desc";
			}

			stmt = conn.prepareStatement(sql);

			stmt.setString(1, vo.getSearchKeyword());

			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {

				int seq = rs.getInt("seq");
				String title = rs.getString("title");
				String nickname = rs.getString("nickname");
				String content = rs.getString("content");
				Date regdate = rs.getDate("regdate");
				int cnt = rs.getInt("cnt");
				String userid = rs.getString("userid");

				BoardVO b = new BoardVO(seq, title, nickname, content, regdate,
						cnt, userid);
				list.add(b);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public BoardVO getBoard(BoardVO vo) {

		BoardVO board = null;

		try {
			conn = JDBCUtils.getConnection();
			String sql = "select * from board where seq = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);

			stmt.setInt(1, vo.getSeq());

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {

				int seq = rs.getInt("seq");
				String title = rs.getString("title");
				String nickname = rs.getString("nickname");
				String content = rs.getString("content");
				Date regdate = rs.getDate("regdate");
				int cnt = rs.getInt("cnt");
				String userid = rs.getString("userid");

				board = new BoardVO(seq, title, nickname, content, regdate,
						cnt, userid);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return board;
	}

	public void insertBoard(BoardVO vo) {

		try {
			conn = JDBCUtils.getConnection();
			String sql = "insert into board(seq,title,nickname,content,userid) "
					+ "values((select nvl(max(seq),0)+1 from board) ,?,?,?,?) ";
			PreparedStatement stmt = conn.prepareStatement(sql);

			stmt.setString(1, vo.getTitle());
			stmt.setString(2, vo.getNickname());
			stmt.setString(3, vo.getContent());
			stmt.setString(4, vo.getUserid());

			stmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt);
		}

	}

	public void updateBoard(BoardVO vo) {

		conn = JDBCUtils.getConnection();

		try {

			String sql = "UPDATE board SET title=?, content=? WHERE seq=?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getTitle());
			stmt.setString(2, vo.getContent());
			stmt.setInt(3, vo.getSeq());
			stmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt);
		}

	}

	public void deleteBoard(BoardVO vo) {

		conn = JDBCUtils.getConnection();
		try {
			String sql = "DELETE FROM board WHERE seq=?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getSeq());
			stmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt);
		}

	}

	public void updateCnt(BoardVO vo) {
		conn = JDBCUtils.getConnection();

		try {

			String sql = "UPDATE board SET cnt = cnt + 1 WHERE seq=?";
			stmt = conn.prepareStatement(sql);

			stmt.setInt(1, vo.getSeq());

			stmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt);
		}

	}

}
