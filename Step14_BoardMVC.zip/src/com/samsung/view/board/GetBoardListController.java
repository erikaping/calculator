package com.samsung.view.board;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;
import com.samsung.view.controller.Controller;

public class GetBoardListController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession();
		String name = (String) session.getAttribute("name");
		String id = (String) session.getAttribute("id");

		if (name == null || id == null) {
			return "login.jsp";

		}

		String searchCondition = "";
		String searchKeyword = "";

		if (request.getParameter("searchCondition") == null) {
			searchCondition = "TITLE";
		} else {
			searchCondition = request.getParameter("searchCondition");
		}
		if (request.getParameter("searchKeyword") == null) {
			searchKeyword = "";
		} else {
			searchKeyword = request.getParameter("searchKeyword");
		}

		BoardDAO dao = new BoardDAO();
		BoardVO vo = new BoardVO();
		vo.setSearchCondition(searchCondition);
		vo.setSearchKeyword(searchKeyword);

		ArrayList<BoardVO> boardList = dao.getBoardList(vo);
		request.setAttribute("boardList", boardList);
		return "getBoardList.jsp";
	}

}
