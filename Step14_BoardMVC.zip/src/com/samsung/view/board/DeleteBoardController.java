package com.samsung.view.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;
import com.samsung.view.controller.Controller;

public class DeleteBoardController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession();
		String name = (String) session.getAttribute("name");
		String id = (String) session.getAttribute("id");

		if (name == null || id == null) {
			return "login.jsp";
		}

		BoardDAO dao = new BoardDAO();
		BoardVO vo = new BoardVO();

		vo.setSeq(Integer.parseInt(request.getParameter("seq")));

		dao.deleteBoard(vo);

		return "getBoardList.do";
	}

}
