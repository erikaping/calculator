package com.samsung.view.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;
import com.samsung.view.controller.Controller;

public class GetBoardController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession();
		String name = (String) session.getAttribute("name");
		String id = (String) session.getAttribute("id");

		if (name == null || id == null) {
			return "login.jsp";

		}

		BoardDAO dao = new BoardDAO();
		BoardVO vo = new BoardVO();
		int seq = 1;
		if (request.getParameter("seq") != null) {
			seq = Integer.parseInt(request.getParameter("seq"));
		}
		vo.setSeq(seq);

		// 조회수 증가 (+1)
		dao.updateCnt(vo);

		BoardVO board = dao.getBoard(vo);

		request.setAttribute("board", board);
		return "getBoard.jsp";
	}

}
