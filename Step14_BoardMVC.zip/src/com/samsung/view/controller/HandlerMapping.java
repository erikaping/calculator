package com.samsung.view.controller;

import java.util.HashMap;

import com.samsung.view.board.DeleteBoardController;
import com.samsung.view.board.GetBoardController;
import com.samsung.view.board.GetBoardListController;
import com.samsung.view.board.InsertBoardController;
import com.samsung.view.board.UpdateBoardController;
import com.samsung.view.user.LoginController;
import com.samsung.view.user.LogoutController;

public class HandlerMapping {
	private HashMap<String, Controller> mappings = null;

	public HandlerMapping() {
		mappings = new HashMap<String, Controller>();
		mappings.put("/login.do", new LoginController());
		mappings.put("/logout.do", new LogoutController());
		mappings.put("/addBoard.do", new InsertBoardController());
		mappings.put("/deleteBoard.do", new DeleteBoardController());
		mappings.put("/updateBoard.do", new UpdateBoardController());
		mappings.put("/getBoard.do", new GetBoardController());
		mappings.put("/getBoardList.do", new GetBoardListController());
	}

	public Controller getController(String path) {
		return mappings.get(path);
	}
}
